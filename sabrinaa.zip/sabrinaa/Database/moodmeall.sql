-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2026 at 07:29 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `moodmeall`
--

-- --------------------------------------------------------

--
-- Table structure for table `meals`
--

CREATE TABLE `meals` (
  `id` int(11) NOT NULL,
  `mood` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `meal_type` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `thumbnail_url` text NOT NULL,
  `ingredients` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`ingredients`)),
  `steps` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`steps`)),
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `meals`
--

INSERT INTO `meals` (`id`, `mood`, `name`, `meal_type`, `description`, `thumbnail_url`, `ingredients`, `steps`, `created_by`, `created_at`) VALUES
(1, 'Happy', 'Dal Pakwan', 'Veg', 'spicy and yummy', 'https://www.spiceupthecurry.com/wp-content/uploads/2017/03/dal-pakwan-1.jpg', '[\"Nulllllllll\"]', '[\"nulllllllllll\"]', 7, '2025-11-28 15:10:54');

-- --------------------------------------------------------

--
-- Table structure for table `meal_restaurants`
--

CREATE TABLE `meal_restaurants` (
  `id` int(11) NOT NULL,
  `meal_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `maps_query` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `meal_restaurants`
--

INSERT INTO `meal_restaurants` (`id`, `meal_id`, `name`, `maps_query`, `created_at`) VALUES
(1, 1, 'Ashapura dal pakwan', 'https://www.google.com/maps/place/Ashapura+Dal+pakvan/@22.3005816,70.8157431,17z/data=!3m1!4b1!4m10!3m9!1s0x3959b5fb6404d519:0xd5b9d9b9f4758376!5m3!1s2025-12-03!4m1!1i2!8m2!3d22.3005817!4d70.820614!16s%2Fg%2F11cmcz6h_c?entry=ttu&g_ep=EgoyMDI1MTEyMy4xIKXMDSoASAFQAw%3D%3D', '2025-11-28 15:12:37');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `user_id`, `token`, `expires_at`, `created_at`) VALUES
(1, 21, '0db7ef421593dc1932475fcd002bd5eaf8b52645a8f3f405f28712e4d0d76244', '2026-01-23 08:25:36', '2026-01-23 11:55:36');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `session_token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `session_token`, `created_at`) VALUES
(1, 1, 'c3333a82d989638bce6c8521549ac113df08909354a1adcd41a03fedb9813d26', '2025-11-26 15:02:52'),
(2, 1, '73c2a1446deca5cfc7b1929089ade40cfc672abda11940ab98187004ef3f65da', '2025-11-26 15:02:52'),
(3, 1, '8aaedeb563e8d6fd6d44b043f17b0740fd16fddb6f48004ed60d956f61cfa336', '2025-11-26 15:19:49'),
(5, 1, '47edb608ee917824cf37c9d361017eb0d9c423f6f88a96e41154ec39d62ba333', '2025-11-26 15:23:46'),
(6, 1, '1ffda4f084f0f945c7ec18345be4ae16142ea675361713b9f9df8b5bb056a514', '2025-11-26 15:28:22'),
(7, 1, '6f8a8fb67344689f344647489daf99df29fa01b8f5db2d3616d91de59f1491a8', '2025-11-26 15:30:53'),
(8, 1, 'd2d6ac41cf620590622d431e7f83bed1c9f637cdc8b7c134dd7a7ae3fea21695', '2025-11-26 15:35:58'),
(17, 5, '1f8dff084b37034a8192e8d98ef0e8b549bbb979851d71d1ed818c613c7ee345', '2025-11-27 07:37:51'),
(18, 1, 'e07891daa236cda9c70687f65679e9d2a975bbc77b4c5dc287387238f4ffb3cd', '2025-11-27 16:50:15'),
(22, 7, 'dd9024988af4fb066580fe92afaacf7486f5a18a0870d4385181cb9bc17dc9c6', '2025-11-28 08:51:52'),
(30, 1, 'bdff6b4edfa76a6b7f602ab73b91eb996004ba71b1451c7fa76396353ab206b6', '2025-11-29 06:23:06'),
(32, 8, '423236c1ec602dbb04d4aff2f14ed81359e61bceef12fab4a0d38aada02b82cf', '2025-11-29 07:03:30'),
(33, 9, '1a5e80e936b7c8e4befa95aeb388c179a67bdc385580d51fd2ded8bd6ecfbf8e', '2026-01-22 09:31:05'),
(37, 10, '9c5e6717ba7e80b56d8caaa41ce51402f3ff70ed8f458e6cd262c44d6d6890ea', '2026-01-22 10:23:33'),
(38, 9, '72d8f929bc7d5009f8ad6a320cca49a935bb1efb0790e1c143457833e5fa721d', '2026-01-22 15:59:33'),
(43, 22, '0b389a0fc92e674a37eb1446632232d6f86e39756c23d88b2c8ee84ca1699760', '2026-01-23 06:28:14');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `otp_code` varchar(6) DEFAULT NULL,
  `otp_expires_at` datetime DEFAULT NULL,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reset_token` varchar(64) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `otp_code`, `otp_expires_at`, `is_verified`, `created_at`, `reset_token`, `token_expiry`) VALUES
(1, 'Maan patel', 'maanpatel4469@gmail.com', '$2y$10$7Axd/n3NJDy8qMZXb1NPMuVrWwPX1XgAcmqzgYNKhiBWEL0ySyC1e', NULL, NULL, 0, '2025-11-26 15:02:23', NULL, NULL),
(3, 'Test User', 'test@example.com', '$2y$10$90jypT8STSo.yR.2jaGfn.mpMD1aQ/dIaSQUQUTRA.suTsag0JFaK', NULL, NULL, 0, '2025-11-26 15:03:05', NULL, NULL),
(4, 'deep', 'deep123@gmail.com', '$2y$10$ebu1hxW5RodvzKp9mHJM8OXR5klYwX7dJwmGl.wRC2E89xg43yMVy', NULL, NULL, 0, '2025-11-27 03:44:57', NULL, NULL),
(5, 'Maan', 'maan123@gmail.com', '$2y$10$MqcOISL3ae.P8FIhRfCh..8KlyYo8Xc07NxEM6Q.Nk4Ue8uz8RK4O', NULL, NULL, 0, '2025-11-27 07:36:35', NULL, NULL),
(6, 'Dhaval', 'D@gmail.com', '$2y$10$qK9.ixz4mf21c23Zf87cLOD7JiHidUxPCEm/5Vmx/pji7optXMTNS', NULL, NULL, 0, '2025-11-28 07:39:42', NULL, NULL),
(8, 'deep', 'deep@gmail.com', '$2y$10$4pNNG5o3vHhvYxUUK/6zqelv/4kfOqWi.QFfScW4XN.TSwK5KkqW.', NULL, NULL, 0, '2025-11-29 07:03:15', NULL, NULL),
(9, 'aaa', 'aaa@gmail.com', '$2y$10$qlhRbiLrqxctmMMNB5x3ResaVBDxUdkqNqgmYOQNoirpko68vZ98S', NULL, NULL, 0, '2026-01-22 09:30:52', NULL, NULL),
(10, 'admin', 'admin@moodmeal.com', '$2y$10$xJIPdoHFRTWmKxOuS2CEWOaJYCt7OpvWbA2cIGGRlXn9uFobdwcYu', NULL, NULL, 0, '2026-01-22 10:21:54', NULL, NULL),
(11, 'p', 'princeparsana278@gmail.com', '$2y$10$XNNFtb1DnQbPz.gqk.PbD.9.N9BlVusFlbNCmRWbACY6iLTxbK1zS', NULL, NULL, 0, '2026-01-22 16:13:03', NULL, NULL),
(21, 'chintan', 'chintankatariya5261@gmail.com', '$2y$10$A7PCZGBd2fN3U6NK3sAs7epJMevw4pMLUv4qAqiZOPz2UnfD0Wsgi', NULL, NULL, 1, '2026-01-23 06:24:19', NULL, NULL),
(22, 'Deep sohaliya ', 'sohaliyadeep512@gmail.com', '$2y$10$jOYO7xaphyM6lC4oVUdrOeOCWCifROBjHXUFFJgGlmFDwFNBqFUGe', NULL, NULL, 1, '2026-01-23 06:26:56', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `meals`
--
ALTER TABLE `meals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meal_restaurants`
--
ALTER TABLE `meal_restaurants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `meal_id` (`meal_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_otp_code` (`otp_code`),
  ADD KEY `idx_is_verified` (`is_verified`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `meals`
--
ALTER TABLE `meals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `meal_restaurants`
--
ALTER TABLE `meal_restaurants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `meal_restaurants`
--
ALTER TABLE `meal_restaurants`
  ADD CONSTRAINT `meal_restaurants_ibfk_1` FOREIGN KEY (`meal_id`) REFERENCES `meals` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
