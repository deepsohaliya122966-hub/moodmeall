const ADMIN_EMAIL = "admin@moodmeal.com";
const API_BASE_URL = window.location.origin + window.location.pathname.replace('admin_panel.html', '').replace(/\/+$/, '') + '/api';

const mealListContainer = document.getElementById("mealList");
const mealSelect = document.getElementById("restaurantMealId");
const adminStatus = document.getElementById("adminStatus");

function getSessionToken() {
    return sessionStorage.getItem("moodMealSessionToken");
}

function getCurrentUser() {
    const stored = sessionStorage.getItem("moodMealUser");
    return stored ? JSON.parse(stored) : null;
}

function renderStatus(message, type = "success") {
    if (!adminStatus) return;
    adminStatus.innerHTML = `
        <div class="status-banner ${type === "success" ? "status-success" : "status-error"}">
            ${message}
        </div>
    `;
}

async function logout() {
    const token = getSessionToken();
    if (token) {
        try {
            await fetch(`${API_BASE_URL}/logout.php`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ session_token: token })
            });
        } catch (error) {
            console.error("Logout failed", error);
        }
    }

    sessionStorage.removeItem("moodMealSessionToken");
    sessionStorage.removeItem("moodMealUser");
    window.location.href = "index.html";
}

function enforceAdmin() {
    const user = getCurrentUser();
    const token = getSessionToken();

    if (!user || !token) {
        renderStatus("You must be logged in to access the admin panel. Redirecting...", "error");
        setTimeout(() => window.location.href = "index.html", 2000);
        return false;
    }

    if (user.email.toLowerCase() !== ADMIN_EMAIL.toLowerCase()) {
        renderStatus("You do not have permission to view this page. Redirecting to dashboard...", "error");
        setTimeout(() => window.location.href = "dashboard.html", 2000);
        return false;
    }

    renderStatus(`Signed in as ${user.name} (${user.email})`, "success");
    return true;
}

async function apiPost(endpoint, payload) {
    const response = await fetch(`${API_BASE_URL}/${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
    });

    const result = await response.json();
    if (!response.ok) {
        throw result;
    }

    return result;
}

function resetFormErrors(form) {
    form.querySelectorAll(".error-text").forEach(el => el.textContent = "");
}

function handleApiErrors(form, errorPayload) {
    if (!errorPayload || !errorPayload.errors) return;
    Object.entries(errorPayload.errors).forEach(([field, message]) => {
        const target = form.querySelector(`[data-error-for="${field}"]`);
        if (target) target.textContent = message;
    });
}

async function fetchMeals() {
    mealListContainer.innerHTML = `<p class="table-empty">Loading meals...</p>`;
    try {
        const response = await fetch(`${API_BASE_URL}/get-meals.php`);
        const data = await response.json();
        if (!data.success) throw new Error(data.message || "Unable to fetch meals.");

        renderMeals(data.meals || []);
        populateMealSelect(data.meals || []);
    } catch (error) {
        mealListContainer.innerHTML = `<p class="table-empty">Failed to load meals. ${error.message || ""}</p>`;
    }
}

function renderMeals(meals) {
    if (!meals.length) {
        mealListContainer.innerHTML = `<p class="table-empty">No meals added yet.</p>`;
        return;
    }

    mealListContainer.innerHTML = meals.map(meal => `
        <div class="meal-list-item">
            <div class="meal-meta">
                <span class="badge">${meal.mood}</span>
                <span class="badge">${meal.meal_type}</span>
            </div>
            <h3>${meal.name}</h3>
            <p class="meal-description">${meal.description}</p>
            <strong>Ingredients</strong>
            <ul>
                ${(meal.ingredients || []).map(ing => `<li>${ing}</li>`).join('')}
            </ul>
            <strong>Steps</strong>
            <ul>
                ${(meal.steps || []).map(step => `<li>${step}</li>`).join('')}
            </ul>
            <strong>Restaurants</strong>
            ${(meal.restaurants || []).length ? `
                <ul>
                    ${(meal.restaurants || []).map(r => `<li>${r.name} — <span class="badge">${r.maps_query}</span></li>`).join('')}
                </ul>
            ` : `<p>No restaurants linked yet.</p>`}
        </div>
    `).join('');
}

function populateMealSelect(meals) {
    if (!mealSelect) return;

    if (!meals.length) {
        mealSelect.innerHTML = `<option value="">No meals available</option>`;
        mealSelect.disabled = true;
        return;
    }

    mealSelect.disabled = false;
    mealSelect.innerHTML = [
        `<option value="">Select a meal</option>`,
        ...meals.map(meal => `<option value="${meal.id}">${meal.name} (${meal.mood})</option>`)
    ].join('');
}

document.addEventListener("DOMContentLoaded", () => {
    if (!enforceAdmin()) {
        return;
    }

    fetchMeals();

    const mealForm = document.getElementById("mealForm");
    const restaurantForm = document.getElementById("restaurantForm");

    mealForm?.addEventListener("submit", async (event) => {
        event.preventDefault();
        resetFormErrors(mealForm);

        const formData = new FormData(mealForm);
        const payload = {
            session_token: getSessionToken(),
            name: formData.get("name"),
            mood: formData.get("mood"),
            meal_type: formData.get("meal_type"),
            description: formData.get("description"),
            thumbnail_url: formData.get("thumbnail_url"),
            ingredients: formData.get("ingredients").split("\n").map(item => item.trim()).filter(Boolean),
            steps: formData.get("steps").split("\n").map(item => item.trim()).filter(Boolean)
        };

        try {
            await apiPost("admin-add-meal.php", payload);
            mealForm.reset();
            renderStatus("Meal saved successfully!", "success");
            fetchMeals();
        } catch (error) {
            renderStatus(error.message || "Failed to save meal.", "error");
            handleApiErrors(mealForm, error);
        }
    });

    restaurantForm?.addEventListener("submit", async (event) => {
        event.preventDefault();
        resetFormErrors(restaurantForm);

        const formData = new FormData(restaurantForm);
        const payload = {
            session_token: getSessionToken(),
            meal_id: formData.get("meal_id"),
            name: formData.get("name"),
            maps_query: formData.get("maps_query")
        };

        try {
            await apiPost("admin-add-restaurant.php", payload);
            restaurantForm.reset();
            renderStatus("Restaurant saved successfully!", "success");
            fetchMeals();
        } catch (error) {
            renderStatus(error.message || "Failed to save restaurant.", "error");
            handleApiErrors(restaurantForm, error);
        }
    });
});

