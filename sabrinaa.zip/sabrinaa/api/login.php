<?php
header("Content-Type: application/json");
require "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$email = $data["email"];
$password = $data["password"];

// find user
$stmt = $conn->prepare("SELECT id, name, email, password, is_verified FROM users WHERE email=? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    http_response_code(401); // Unauthorized
    echo json_encode(["success" => false, "message" => "Invalid email or password"]);
    exit;
}

$stmt->bind_result($id, $name, $fetched_email, $hashed, $isVerified);
$stmt->fetch();

// verify password
if (!password_verify($password, $hashed)) {
    http_response_code(401); // Unauthorized
    echo json_encode(["success" => false, "message" => "Invalid email or password"]);
    exit;
}

// Check if email is verified
if ($isVerified != 1) {
    http_response_code(403); // Forbidden
    echo json_encode([
        "success" => false,
        "message" => "Please verify your email address before logging in. Check your inbox for the OTP code.",
        "email" => $email,
        "needs_verification" => true
    ]);
    exit;
}

// generate session token
$token = bin2hex(random_bytes(32));
$save = $conn->prepare("INSERT INTO sessions (user_id, session_token, created_at) VALUES (?, ?, NOW())"); // Added created_at column for future cleanup
$save->bind_param("is", $id, $token);
$save->execute();

echo json_encode([
    "success" => true,
    "message" => "Login successful",
    "session_token" => $token,
    "user" => [
        "id" => $id,
        "name" => $name,
        // Fixed: Use the email fetched from the DB for consistency
        "email" => $fetched_email 
    ]
]);
?>