<?php
// Suppress errors to prevent HTML output in JSON responses
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Load PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer files with error handling
$phpmailerPath = __DIR__ . '/../PHPMailer-master/src/';
if (!file_exists($phpmailerPath . 'Exception.php')) {
    // PHPMailer not found - define stub functions
    if (!function_exists('sendEmail')) {
        function sendEmail($to, $subject, $body, $altBody = '') {
            return ['success' => false, 'message' => 'PHPMailer library not found. Please ensure PHPMailer-master folder exists.'];
        }
    }
    if (!function_exists('sendOTPEmail')) {
        function sendOTPEmail($email, $otpCode, $name = '') {
            return ['success' => false, 'message' => 'PHPMailer library not found. Please ensure PHPMailer-master folder exists.'];
        }
    }
    if (!function_exists('sendPasswordResetEmail')) {
        function sendPasswordResetEmail($email, $resetToken) {
            return ['success' => false, 'message' => 'PHPMailer library not found. Please ensure PHPMailer-master folder exists.'];
        }
    }
} else {
    require_once $phpmailerPath . 'Exception.php';
    require_once $phpmailerPath . 'PHPMailer.php';
    require_once $phpmailerPath . 'SMTP.php';
}

// Include mail configuration
require_once __DIR__ . '/mail-config.php';

/**
 * Send email using PHPMailer with SMTP
 * 
 * @param string $to Recipient email address
 * @param string $subject Email subject
 * @param string $body Email body (HTML)
 * @param string $altBody Plain text alternative (optional)
 * @return array Returns ['success' => bool, 'message' => string]
 */
function sendEmail($to, $subject, $body, $altBody = '') {
    // Check if SMTP credentials are configured
    if (SMTP_USERNAME === 'your-email@gmail.com' || 
        SMTP_PASSWORD === 'your-app-password' || 
        SMTP_PASSWORD === 'your-16-char-app-password-here' ||
        empty(trim(SMTP_PASSWORD)) ||
        strlen(trim(SMTP_PASSWORD)) < 10) {
        return [
            'success' => false,
            'message' => 'SMTP credentials not configured. Please update api/mail-config.php with your Gmail App Password. Get it from: https://myaccount.google.com/apppasswords'
        ];
    }
    
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_ENCRYPTION === 'ssl' ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        $mail->CharSet    = 'UTF-8';
        
        // Enable debug output (only if SMTP_DEBUG is true)
        if (SMTP_DEBUG) {
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;
            $mail->Debugoutput = function($str, $level) {
                error_log("PHPMailer Debug: $str");
            };
        }
        
        // Timeout settings
        $mail->Timeout = 30;
        
        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($to);
        $mail->addReplyTo(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = !empty($altBody) ? $altBody : strip_tags($body);
        
        $mail->send();
        return ['success' => true, 'message' => 'Email sent successfully'];
        
    } catch (Exception $e) {
        $errorMsg = $mail->ErrorInfo ?: $e->getMessage();
        return [
            'success' => false,
            'message' => "Email could not be sent. Error: " . $errorMsg
        ];
    }
}

/**
 * Send password reset email
 * 
 * @param string $email User email address
 * @param string $resetToken Password reset token
 * @return array Returns ['success' => bool, 'message' => string]
 */
function sendPasswordResetEmail($email, $resetToken) {
    $resetLink = rtrim(RESET_BASE_URL, '/') . '/reset-password.html?token=' . urlencode($resetToken);
    
    $subject = "Password Reset Request - MoodMeall";
    $body = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .button { display: inline-block; padding: 12px 24px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
            .button:hover { background-color: #45a049; }
        </style>
    </head>
    <body>
        <div class='container'>
            <h2>Password Reset Request</h2>
            <p>Hello,</p>
            <p>You have requested to reset your password. Click the button below to reset it:</p>
            <a href='{$resetLink}' class='button'>Reset Password</a>
            <p>Or copy and paste this link into your browser:</p>
            <p>{$resetLink}</p>
            <p>This link will expire in 1 hour.</p>
            <p>If you did not request this password reset, please ignore this email.</p>
            <p>Best regards,<br>MoodMeall Team</p>
        </div>
    </body>
    </html>
    ";
    
    $altBody = "Password Reset Request\n\nClick this link to reset your password: {$resetLink}\n\nThis link will expire in 1 hour.";
    
    return sendEmail($email, $subject, $body, $altBody);
}

/**
 * Send OTP verification email
 * 
 * @param string $email User email address
 * @param string $otpCode 6-digit OTP code
 * @param string $name User's name (optional)
 * @return array Returns ['success' => bool, 'message' => string]
 */
function sendOTPEmail($email, $otpCode, $name = '') {
    $subject = "Verify Your Email - MoodMeall";
    $greeting = !empty($name) ? "Hello {$name}," : "Hello,";
    
    $body = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .otp-box { background-color: #f4f4f4; border: 2px dashed #4CAF50; padding: 20px; text-align: center; margin: 20px 0; border-radius: 10px; }
            .otp-code { font-size: 32px; font-weight: bold; color: #4CAF50; letter-spacing: 5px; font-family: 'Courier New', monospace; }
            .warning { color: #ff6b6b; font-size: 14px; margin-top: 10px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <h2>Email Verification</h2>
            <p>{$greeting}</p>
            <p>Thank you for registering with MoodMeall! Please verify your email address using the OTP code below:</p>
            <div class='otp-box'>
                <div class='otp-code'>{$otpCode}</div>
            </div>
            <p class='warning'>This OTP will expire in 10 minutes.</p>
            <p>If you did not create an account with MoodMeall, please ignore this email.</p>
            <p>Best regards,<br>MoodMeall Team</p>
        </div>
    </body>
    </html>
    ";
    
    $altBody = "Email Verification\n\n{$greeting}\n\nThank you for registering with MoodMeall! Please verify your email address using the OTP code below:\n\nOTP Code: {$otpCode}\n\nThis OTP will expire in 10 minutes.\n\nIf you did not create an account with MoodMeall, please ignore this email.\n\nBest regards,\nMoodMeall Team";
    
    return sendEmail($email, $subject, $body, $altBody);
}
?>