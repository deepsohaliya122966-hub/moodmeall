<?php
header("Content-Type: application/json");
require "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$token = isset($data["token"]) ? trim($data["token"]) : "";
$newPassword = $data["newPassword"] ?? "";
$confirmPassword = $data["confirmPassword"] ?? "";

$errors = [];

if (strlen($token) < 32) {
    $errors["token"] = "Invalid or expired reset link.";
}

if (strlen($newPassword) < 6) {
    $errors["password"] = "Password must be at least 6 characters.";
} elseif ($newPassword !== $confirmPassword) {
    $errors["password"] = "Passwords do not match.";
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(["success" => false, "errors" => $errors]);
    exit;
}

$stmt = $conn->prepare("SELECT user_id, expires_at FROM password_resets WHERE token = ? LIMIT 1");
$stmt->bind_param("s", $token);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Invalid or expired reset link. Please request a new one."]);
    exit;
}

$stmt->bind_result($userId, $expiresAt);
$stmt->fetch();
$stmt->close();

if (strtotime($expiresAt) < time()) {
    $expired = $conn->prepare("DELETE FROM password_resets WHERE token = ?");
    $expired->bind_param("s", $token);
    $expired->execute();
    $expired->close();
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "This reset link has expired. Please request a new one."]);
    exit;
}

$hashed = password_hash($newPassword, PASSWORD_DEFAULT);
$up = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
$up->bind_param("si", $hashed, $userId);
$up->execute();
$up->close();

$del = $conn->prepare("DELETE FROM password_resets WHERE token = ?");
$del->bind_param("s", $token);
$del->execute();
$del->close();

echo json_encode(["success" => true, "message" => "Password updated successfully. You can now log in with your new password."]);
