<?php
header("Content-Type: application/json");
require "db.php";
require "mail-helper.php";

$data = json_decode(file_get_contents("php://input"), true);

$email = isset($data["email"]) ? trim($data["email"]) : "";

$errors = [];

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors["email"] = "Please enter a valid email address.";
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(["success" => false, "errors" => $errors]);
    exit;
}

$stmt = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    http_response_code(404);
    echo json_encode(["success" => false, "message" => "No account found for this email."]);
    exit;
}

$stmt->bind_result($userId);
$stmt->fetch();
$stmt->close();

// Generate reset token
$resetToken = bin2hex(random_bytes(32));
$expiresAt = date('Y-m-d H:i:s', strtotime('+1 hour'));

// Remove any existing reset for this user, then store new token in password_resets
$del = $conn->prepare("DELETE FROM password_resets WHERE user_id = ?");
$del->bind_param("i", $userId);
$del->execute();
$del->close();

$ins = $conn->prepare("INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)");
$ins->bind_param("iss", $userId, $resetToken, $expiresAt);
$ins->execute();
$ins->close();

// Send password reset email
$emailResult = sendPasswordResetEmail($email, $resetToken);

if ($emailResult['success']) {
    echo json_encode([
        "success" => true,
        "message" => "Password reset link has been sent to your email address."
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Failed to send email. Please try again later."
    ]);
}
