<?php
header("Content-Type: application/json");
require "mail-helper.php";

$to = isset($_GET["to"]) ? trim($_GET["to"]) : "";
if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Provide a valid 'to' email, e.g. ?to=you@example.com"]);
    exit;
}

$result = sendEmail(
    $to,
    "Test Email - MoodMeall",
    "<h1>Test Email</h1><p>This is a test email from PHPMailer via SMTP.</p>",
    "This is a test email from PHPMailer via SMTP."
);

echo json_encode($result);
