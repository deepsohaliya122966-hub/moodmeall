<?php
// Test SMTP Configuration
header("Content-Type: application/json");
require "mail-helper.php";

$testEmail = isset($_GET["email"]) ? trim($_GET["email"]) : "";

if (empty($testEmail) || !filter_var($testEmail, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Please provide a valid email address. Usage: test-smtp.php?email=your@email.com"
    ]);
    exit;
}

// Check configuration
$configStatus = [];
$configStatus['SMTP_HOST'] = defined('SMTP_HOST') ? SMTP_HOST : 'NOT SET';
$configStatus['SMTP_PORT'] = defined('SMTP_PORT') ? SMTP_PORT : 'NOT SET';
$configStatus['SMTP_USERNAME'] = defined('SMTP_USERNAME') ? (SMTP_USERNAME === 'your-email@gmail.com' ? 'NOT CONFIGURED' : 'CONFIGURED') : 'NOT SET';
$configStatus['SMTP_PASSWORD'] = defined('SMTP_PASSWORD') ? (SMTP_PASSWORD === 'your-app-password' ? 'NOT CONFIGURED' : 'CONFIGURED') : 'NOT SET';
$configStatus['SMTP_FROM_EMAIL'] = defined('SMTP_FROM_EMAIL') ? SMTP_FROM_EMAIL : 'NOT SET';
$configStatus['SMTP_ENCRYPTION'] = defined('SMTP_ENCRYPTION') ? SMTP_ENCRYPTION : 'NOT SET';

// Send test email
$result = sendEmail(
    $testEmail,
    "Test Email - MoodMeall SMTP Configuration",
    "<h1>SMTP Test Email</h1><p>If you received this email, your SMTP configuration is working correctly!</p><p>Sent at: " . date('Y-m-d H:i:s') . "</p>",
    "SMTP Test Email - If you received this email, your SMTP configuration is working correctly!"
);

echo json_encode([
    "success" => $result['success'],
    "message" => $result['message'],
    "config_status" => $configStatus,
    "test_email" => $testEmail
], JSON_PRETTY_PRINT);

?>
