<?php
header("Content-Type: application/json");
require "db.php";
require "mail-helper.php";

$data = json_decode(file_get_contents("php://input"), true);

$email = isset($data["email"]) ? trim($data["email"]) : "";

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Invalid email format"]);
    exit;
}

// Find user
$stmt = $conn->prepare("SELECT id, name, is_verified FROM users WHERE email = ? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    http_response_code(404);
    echo json_encode(["success" => false, "message" => "No account found for this email. Please register first."]);
    exit;
}

$stmt->bind_result($userId, $name, $isVerified);
$stmt->fetch();
$stmt->close();

// Check if already verified
if ($isVerified == 1) {
    echo json_encode([
        "success" => true,
        "message" => "Email already verified. You can log in now."
    ]);
    exit;
}

// Generate new OTP
$otpCode = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
$otpExpiresAt = date('Y-m-d H:i:s', strtotime('+10 minutes'));

// Update OTP in database
$update = $conn->prepare("UPDATE users SET otp_code = ?, otp_expires_at = ? WHERE id = ?");
$update->bind_param("ssi", $otpCode, $otpExpiresAt, $userId);
$update->execute();
$update->close();

// Send OTP email
$emailResult = sendOTPEmail($email, $otpCode, $name);

if ($emailResult['success']) {
    echo json_encode([
        "success" => true,
        "message" => "A new OTP code has been sent to your email address."
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Failed to send OTP email. Please try again later."
    ]);
}

?>
