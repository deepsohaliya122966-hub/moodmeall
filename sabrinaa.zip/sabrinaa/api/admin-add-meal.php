<?php
header("Content-Type: application/json");
require "db.php";
require "admin-helpers.php";

$data = json_decode(file_get_contents("php://input"), true);

// FIX: Use isset() checks instead of the PHP 7+ null coalescing operator (??)
$sessionToken = isset($data["session_token"]) ? $data["session_token"] : null;
$adminId = require_admin($conn, $sessionToken);

$name = trim(isset($data["name"]) ? $data["name"] : "");
$mood = trim(isset($data["mood"]) ? $data["mood"] : "");
$mealType = trim(isset($data["meal_type"]) ? $data["meal_type"] : "");
$description = trim(isset($data["description"]) ? $data["description"] : "");
$thumbnail = trim(isset($data["thumbnail_url"]) ? $data["thumbnail_url"] : "");
$ingredients = isset($data["ingredients"]) ? $data["ingredients"] : [];
$steps = isset($data["steps"]) ? $data["steps"] : [];

$errors = [];

if ($name === "") $errors["name"] = "Meal name is required.";
if ($mood === "") $errors["mood"] = "Mood is required.";
if ($mealType === "") $errors["meal_type"] = "Meal type is required.";
if ($description === "") $errors["description"] = "Description is required.";
if ($thumbnail === "") $errors["thumbnail_url"] = "Thumbnail URL is required.";
if (!is_array($ingredients) || count(array_filter($ingredients)) === 0) $errors["ingredients"] = "Provide at least one ingredient.";
if (!is_array($steps) || count(array_filter($steps)) === 0) $errors["steps"] = "Provide at least one instruction step.";

if (!empty($errors)) {
    respond_json(422, ["success" => false, "errors" => $errors]);
}

$ingredientsJson = json_encode(array_values(array_filter(array_map('trim', $ingredients))));
$stepsJson = json_encode(array_values(array_filter(array_map('trim', $steps))));

$stmt = $conn->prepare("INSERT INTO meals (mood, name, meal_type, description, thumbnail_url, ingredients, steps, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
$stmt->bind_param("sssssssi", $mood, $name, $mealType, $description, $thumbnail, $ingredientsJson, $stepsJson, $adminId);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Meal added successfully."]);
} else {
    respond_json(500, ["success" => false, "message" => "Database error while adding meal."]);
}
?>