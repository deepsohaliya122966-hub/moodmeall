<?php
header("Content-Type: application/json");
require "db.php";

$data = json_decode(file_get_contents("php://input"), true);
$token = $data["session_token"];

$stmt = $conn->prepare("DELETE FROM sessions WHERE session_token=?");
$stmt->bind_param("s", $token);
$stmt->execute();

echo json_encode(["success" => true, "message" => "Logged out successfully"]);
?>