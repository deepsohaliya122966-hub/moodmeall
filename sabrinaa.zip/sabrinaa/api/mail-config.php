<?php
// SMTP Configuration
// ⚠️ IMPORTANT: Replace the placeholder values below with your actual Gmail credentials

define('SMTP_HOST', 'smtp.gmail.com');        // Gmail SMTP server
define('SMTP_PORT', 587);                     // Port 587 for TLS (or 465 for SSL)
define('SMTP_USERNAME', 'sohaliyadeep512@gmail.com'); // ⚠️ YOUR GMAIL ADDRESS
define('SMTP_PASSWORD', 'hysk yktm gqrp adrz');   // ⚠️ REPLACE WITH YOUR GMAIL APP PASSWORD (16 characters, no spaces)
define('SMTP_FROM_EMAIL', 'sohaliyadeep512@gmail.com'); // ⚠️ YOUR GMAIL ADDRESS
define('SMTP_FROM_NAME', 'MoodMeall');        // From name
define('SMTP_ENCRYPTION', 'tls');             // 'tls' for port 587, or 'ssl' for port 465
define('SMTP_DEBUG', true);                   // Set to false in production after testing

// Base URL for password reset links (no trailing slash)
define('RESET_BASE_URL', 'http://localhost/sabrinaa');

/*
 * HOW TO GET GMAIL APP PASSWORD:
 * 
 * 1. Go to: https://myaccount.google.com/apppasswords
 * 2. Sign in with: sohaliyadeep512@gmail.com
 * 3. If 2-Step Verification is not enabled, enable it first at:
 *    https://myaccount.google.com/security
 * 4. Select "Mail" and "Other (Custom name)"
 * 5. Enter "MoodMeall" as the name
 * 6. Click "Generate"
 * 7. Copy the 16-character password (it will look like: abcd efgh ijkl mnop)
 * 8. Paste it above in SMTP_PASSWORD (remove spaces: abcdefghijklmnop)
 */
?>