<?php
session_start();

// 1. SECURITY: Check if user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.html");
    exit();
}

// 2. SECURITY: Prevent Browser Caching (So "Back" doesn't show old info)
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>

<!DOCTYPE html>
<html>
<head>
    <title>MoodMeal Home</title>
    <link rel="stylesheet" href="style.css">
    
    <script type="text/javascript">
        // --- THE BACK BUTTON FIX ---
        // This forces the browser to stay on this page if they click "Back"
        function preventBack() { 
            window.history.forward(); 
        }
        
        setTimeout("preventBack()", 0);
        
        window.onunload = function () { null };
    </script>
</head>
<body>

    <h1>Welcome, <?php echo $_SESSION['name']; ?>!</h1>
    <p>You are now logged in.</p>

    <a href="logout.php">
        <button style="background-color: #ff4d4d; color: white;">Logout</button>
    </a>

</body>
</html>