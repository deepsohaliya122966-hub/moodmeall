<?php
header("Content-Type: application/json");
require "db.php";

function respond($status, $payload) {
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

$mealsResult = $conn->query("SELECT id, mood, name, meal_type, description, thumbnail_url, ingredients, steps, created_at FROM meals ORDER BY created_at DESC");

if (!$mealsResult) {
    respond(500, [
        "success" => false,
        "message" => "Failed to load meals. Please ensure the 'meals' table exists. Details: " . $conn->error
    ]);
}

$mealIds = [];
$meals = [];

if ($mealsResult) {
    while ($row = $mealsResult->fetch_assoc()) {
        // FIX: Replaced PHP 7+ operator (??) with isset() checks
        $ingredients_json = isset($row["ingredients"]) ? $row["ingredients"] : "[]";
        $steps_json = isset($row["steps"]) ? $row["steps"] : "[]";
        
        // json_decode returns null on error. The ?: [] ensures an empty array is used instead of null.
        $row["ingredients"] = json_decode($ingredients_json, true) ?: [];
        $row["steps"] = json_decode($steps_json, true) ?: [];
        
        $row["restaurants"] = [];
        $meals[$row["id"]] = $row;
        $mealIds[] = $row["id"];
    }
}

if (!empty($mealIds)) {
    $idList = implode(",", array_map("intval", $mealIds));
    $restaurantsResult = $conn->query("SELECT id, meal_id, name, maps_query FROM meal_restaurants WHERE meal_id IN ($idList) ORDER BY created_at DESC");

    if (!$restaurantsResult) {
        respond(500, [
            "success" => false,
            "message" => "Failed to load restaurants. Please ensure the 'meal_restaurants' table exists. Details: " . $conn->error
        ]);
    }

    while ($restaurant = $restaurantsResult->fetch_assoc()) {
        if (isset($meals[$restaurant["meal_id"]])) {
            $meals[$restaurant["meal_id"]]["restaurants"][] = $restaurant;
        }
    }
}

echo json_encode([
    "success" => true,
    "meals" => array_values($meals)
]);
?>