<?php
header("Content-Type: application/json");
require "db.php";

$data = json_decode(file_get_contents("php://input"), true);
$token = $data["session_token"];

$stmt = $conn->prepare("SELECT users.id, users.name, users.email 
                        FROM sessions 
                        JOIN users ON sessions.user_id = users.id 
                        WHERE sessions.session_token=?");
$stmt->bind_param("s", $token);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    echo json_encode(["success" => false, "message" => "Invalid session"]);
    exit;
}

$stmt->bind_result($id, $name, $email);
$stmt->fetch();

echo json_encode([
    "success" => true,
    "user" => [
        "id" => $id,
        "name" => $name,
        "email" => $email
    ]
]);
?>
