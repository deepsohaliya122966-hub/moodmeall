<?php
// Turn off error display, but log errors
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Start output buffering to catch any unexpected output
ob_start();

header("Content-Type: application/json");
require "db.php";
require "mail-helper.php";

$data = json_decode(file_get_contents("php://input"), true);

$name = $data["name"] ?? "";
$email = $data["email"] ?? "";
$password = $data["password"] ?? "";
$confirm = $data["confirmPassword"] ?? "";

$errors = [];

// Validation
if (empty($name) || strlen(trim($name)) < 2) {
    $errors["name"] = "Name must be at least 2 characters";
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors["email"] = "Invalid email format";
}
if (strlen($password) < 6) {
    $errors["password"] = "Password must be at least 6 characters";
}
if ($password !== $confirm) {
    $errors["password"] = "Passwords do not match";
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(["success" => false, "errors" => $errors, "message" => "Validation failed"]);
    exit;
}

// Check if email already exists
// First check if is_verified column exists
$checkColumns = $conn->query("SHOW COLUMNS FROM users LIKE 'is_verified'");
$hasIsVerified = $checkColumns && $checkColumns->num_rows > 0;

if ($hasIsVerified) {
    $check = $conn->prepare("SELECT id, is_verified FROM users WHERE email=?");
} else {
    $check = $conn->prepare("SELECT id FROM users WHERE email=?");
}
$check->bind_param("s", $email);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    if ($hasIsVerified) {
        $check->bind_result($existingId, $isVerified);
        $check->fetch();
        
        // If user exists but not verified, allow re-registration (resend OTP)
        if ($isVerified == 1) {
            ob_clean();
            http_response_code(409);
            echo json_encode(["success" => false, "message" => "This email is already registered and verified"]);
            ob_end_flush();
            exit;
        } else {
            // User exists but not verified - delete old record to allow re-registration
            $del = $conn->prepare("DELETE FROM users WHERE id=?");
            $del->bind_param("i", $existingId);
            $del->execute();
            $del->close();
        }
    } else {
        // Column doesn't exist - just check if email exists
        $check->bind_result($existingId);
        $check->fetch();
        ob_clean();
        http_response_code(409);
        echo json_encode([
            "success" => false,
            "message" => "This email is already registered. Please run Database/add_otp_columns.sql to enable OTP verification."
        ]);
        ob_end_flush();
        exit;
    }
}
$check->close();

// Generate 6-digit OTP
$otpCode = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
$otpExpiresAt = date('Y-m-d H:i:s', strtotime('+10 minutes'));

$hashed = password_hash($password, PASSWORD_DEFAULT);

// Insert user with is_verified = 0
// Check if OTP columns exist
$checkOtpColumns = $conn->query("SHOW COLUMNS FROM users LIKE 'otp_code'");
$hasOtpColumns = $checkOtpColumns && $checkOtpColumns->num_rows > 0;

if ($hasOtpColumns) {
    $stmt = $conn->prepare("INSERT INTO users (name, email, password, otp_code, otp_expires_at, is_verified) VALUES (?, ?, ?, ?, ?, 0)");
    $stmt->bind_param("sssss", $name, $email, $hashed, $otpCode, $otpExpiresAt);
} else {
    // Fallback: insert without OTP columns (for backward compatibility)
    $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $hashed);
    // Set OTP to null since columns don't exist
    $otpCode = null;
}

// Clear any output buffer before JSON response
ob_clean();

if ($stmt->execute()) {
    // Send OTP email only if OTP columns exist
    if ($hasOtpColumns && $otpCode !== null) {
        $emailResult = sendOTPEmail($email, $otpCode, $name);
        
        if ($emailResult['success']) {
            echo json_encode([
                "success" => true,
                "message" => "Registration successful! Please check your email for the OTP code.",
                "email" => $email
            ]);
        } else {
            // Registration succeeded but email failed - return error with details
            // Don't return 500, return 200 with success=false so frontend can show the error
            echo json_encode([
                "success" => false,
                "message" => "Account created but email could not be sent: " . $emailResult['message'],
                "email" => $email,
                "error" => $emailResult['message'],
                "note" => "Please check your SMTP configuration in api/mail-config.php. The account was created successfully, but you need to verify your email manually or configure SMTP."
            ]);
        }
    } else {
        // OTP columns don't exist - return error asking to run migration
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Database migration required. Please run Database/add_otp_columns.sql first."
        ]);
    }
} else {
    // Get the actual database error
    $error = $conn->error;
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Database error: " . ($error ?: "Unknown error. Please check if OTP columns exist in users table.")
    ]);
}

$stmt->close();
ob_end_flush();
?>
