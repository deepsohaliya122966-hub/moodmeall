<?php
header("Content-Type: application/json");
require "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$email = isset($data["email"]) ? trim($data["email"]) : "";
$otpCode = isset($data["otp"]) ? trim($data["otp"]) : "";

$errors = [];

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors["email"] = "Invalid email format";
}

if (empty($otpCode) || strlen($otpCode) !== 6 || !ctype_digit($otpCode)) {
    $errors["otp"] = "Please enter a valid 6-digit OTP code";
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(["success" => false, "errors" => $errors]);
    exit;
}

// Find user with matching email and OTP
$stmt = $conn->prepare("SELECT id, otp_code, otp_expires_at, is_verified FROM users WHERE email = ? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    http_response_code(404);
    echo json_encode(["success" => false, "message" => "No account found for this email. Please register first."]);
    exit;
}

$stmt->bind_result($userId, $storedOtp, $otpExpiresAt, $isVerified);
$stmt->fetch();
$stmt->close();

// Check if already verified
if ($isVerified == 1) {
    echo json_encode([
        "success" => true,
        "message" => "Email already verified. You can now log in.",
        "already_verified" => true
    ]);
    exit;
}

// Check if OTP expired
if (strtotime($otpExpiresAt) < time()) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "OTP has expired. Please request a new one."]);
    exit;
}

// Verify OTP code
if ($storedOtp !== $otpCode) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Invalid OTP code. Please check and try again."]);
    exit;
}

// OTP is valid - verify the user
$update = $conn->prepare("UPDATE users SET is_verified = 1, otp_code = NULL, otp_expires_at = NULL WHERE id = ?");
$update->bind_param("i", $userId);
$update->execute();
$update->close();

echo json_encode([
    "success" => true,
    "message" => "Email verified successfully! You can now log in."
]);

?>
