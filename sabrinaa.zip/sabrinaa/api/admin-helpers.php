<?php

function respond_json($statusCode, $payload) {
    http_response_code($statusCode);
    echo json_encode($payload);
    exit;
}

function require_admin(mysqli $conn, ?string $sessionToken) {
    if (!$sessionToken) {
        respond_json(401, ["success" => false, "message" => "Missing session token."]);
    }

    $adminEmails = [
        "admin@moodmeal.com"
    ];

    $stmt = $conn->prepare(
        "SELECT users.id, users.email 
         FROM sessions 
         JOIN users ON sessions.user_id = users.id 
         WHERE sessions.session_token = ? LIMIT 1"
    );
    $stmt->bind_param("s", $sessionToken);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        respond_json(401, ["success" => false, "message" => "Invalid session token. Please log in again."]);
    }

    $stmt->bind_result($userId, $email);
    $stmt->fetch();
    $stmt->close();

    if (!in_array(strtolower($email), array_map('strtolower', $adminEmails), true)) {
        respond_json(403, ["success" => false, "message" => "You do not have admin privileges."]);
    }

    return $userId;
}
?>

