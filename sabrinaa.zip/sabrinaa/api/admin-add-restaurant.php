<?php
header("Content-Type: application/json");
require "db.php";
require "admin-helpers.php";

$data = json_decode(file_get_contents("php://input"), true);

// FIX: Use isset() checks instead of the PHP 7+ null coalescing operator (??)
$sessionToken = isset($data["session_token"]) ? $data["session_token"] : null;
require_admin($conn, $sessionToken);

$mealId = (int) (isset($data["meal_id"]) ? $data["meal_id"] : 0);
$name = trim(isset($data["name"]) ? $data["name"] : "");
$query = trim(isset($data["maps_query"]) ? $data["maps_query"] : "");

$errors = [];

if ($mealId <= 0) $errors["meal_id"] = "Select a meal to attach this restaurant.";
if ($name === "") $errors["name"] = "Restaurant name is required.";
if ($query === "") $errors["maps_query"] = "Provide a search query or address.";

if (!empty($errors)) {
    respond_json(422, ["success" => false, "errors" => $errors]);
}

$stmt = $conn->prepare("SELECT id FROM meals WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $mealId);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    respond_json(404, ["success" => false, "message" => "Meal not found."]);
}
$stmt->close();

$insert = $conn->prepare("INSERT INTO meal_restaurants (meal_id, name, maps_query, created_at) VALUES (?, ?, ?, NOW())");
$insert->bind_param("iss", $mealId, $name, $query);

if ($insert->execute()) {
    echo json_encode(["success" => true, "message" => "Restaurant added successfully."]);
} else {
    respond_json(500, ["success" => false, "message" => "Database error while saving restaurant."]);
}
?>