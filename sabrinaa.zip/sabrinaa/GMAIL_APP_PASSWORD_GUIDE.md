# How to Fix "Could not authenticate" Error

## The Problem
You're getting: **"SMTP Error: Could not authenticate"**

This means you're still using a placeholder password instead of your actual Gmail App Password.

## Solution: Get Your Gmail App Password

### Step 1: Enable 2-Step Verification (Required)

1. Go to: **https://myaccount.google.com/security**
2. Sign in with: `sohaliyadeep512@gmail.com`
3. Find "2-Step Verification" section
4. Click "Get started" or "Turn on" if not already enabled
5. Follow the setup process (you'll need your phone)

### Step 2: Generate App Password

1. Go to: **https://myaccount.google.com/apppasswords**
2. Sign in with: `sohaliyadeep512@gmail.com`
3. If you see "App passwords aren't available for your account":
   - You need to enable 2-Step Verification first (go back to Step 1)
4. Select:
   - **App:** Mail
   - **Device:** Other (Custom name)
   - **Name:** Enter "MoodMeall"
5. Click **"Generate"**
6. You'll see a 16-character password like: `abcd efgh ijkl mnop`

### Step 3: Update mail-config.php

1. Open: `api/mail-config.php`
2. Find line 8:
   ```php
   define('SMTP_PASSWORD', 'your-16-char-app-password-here');
   ```
3. Replace with your App Password (remove spaces):
   ```php
   define('SMTP_PASSWORD', 'abcdefghijklmnop'); // Your actual 16-char app password
   ```

**Important:**
- Remove ALL spaces from the App Password
- Use the 16-character password, NOT your regular Gmail password
- Make sure there are no extra quotes or characters

### Step 4: Test

1. Test SMTP: `http://localhost/sabrinaa/api/test-smtp.php?email=sohaliyadeep512@gmail.com`
2. Try registration again

## Alternative: Try Port 465 with SSL

If port 587 doesn't work, try port 465 with SSL:

In `api/mail-config.php`:
```php
define('SMTP_PORT', 465);        // Change from 587 to 465
define('SMTP_ENCRYPTION', 'ssl'); // Change from 'tls' to 'ssl'
```

## Common Mistakes

❌ **Using your regular Gmail password** → Won't work, must use App Password
❌ **Leaving spaces in App Password** → Remove all spaces
❌ **2-Step Verification not enabled** → Must enable first
❌ **Copying password with extra characters** → Only copy the 16 characters

✅ **Correct:** `abcdefghijklmnop` (16 chars, no spaces)
❌ **Wrong:** `abcd efgh ijkl mnop` (has spaces)
❌ **Wrong:** `'abcdefghijklmnop'` (extra quotes)

## Still Having Issues?

1. **Double-check 2-Step Verification is enabled**
2. **Generate a NEW App Password** (delete old one and create new)
3. **Try port 465 with SSL** instead of 587 with TLS
4. **Check for typos** in the password
5. **Wait 5 minutes** after generating App Password (Google needs time to activate it)
