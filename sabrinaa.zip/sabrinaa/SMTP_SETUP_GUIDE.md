# SMTP Email Configuration Guide

## Quick Fix for "Email could not be sent" Error

### Step 1: Open `api/mail-config.php`

Edit the file and replace the placeholder values with your actual email credentials.

### Step 2: For Gmail Users

1. **Enable 2-Step Verification:**
   - Go to: https://myaccount.google.com/security
   - Enable "2-Step Verification" if not already enabled

2. **Create App Password:**
   - Go to: https://myaccount.google.com/apppasswords
   - Select "Mail" and "Other (Custom name)"
   - Enter "MoodMeall" as the name
   - Click "Generate"
   - Copy the 16-character password (it will look like: `abcd efgh ijkl mnop`)

3. **Update `api/mail-config.php`:**
   ```php
   define('SMTP_USERNAME', 'your-actual-email@gmail.com');
   define('SMTP_PASSWORD', 'abcdefghijklmnop'); // Use the 16-char app password (no spaces)
   define('SMTP_FROM_EMAIL', 'your-actual-email@gmail.com');
   ```

### Step 3: For Other Email Providers

#### Outlook/Hotmail:
```php
define('SMTP_HOST', 'smtp-mail.outlook.com');
define('SMTP_PORT', 587);
define('SMTP_ENCRYPTION', 'tls');
define('SMTP_USERNAME', 'your-email@outlook.com');
define('SMTP_PASSWORD', 'your-password');
define('SMTP_FROM_EMAIL', 'your-email@outlook.com');
```

#### Yahoo:
```php
define('SMTP_HOST', 'smtp.mail.yahoo.com');
define('SMTP_PORT', 587);
define('SMTP_ENCRYPTION', 'tls');
define('SMTP_USERNAME', 'your-email@yahoo.com');
define('SMTP_PASSWORD', 'your-app-password'); // Yahoo also requires app password
define('SMTP_FROM_EMAIL', 'your-email@yahoo.com');
```

### Step 4: Test Your Configuration

1. Open in browser:
   ```
   http://localhost/sabrinaa/api/test-smtp.php?email=your@email.com
   ```

2. Check the response - it should show:
   - Configuration status
   - Whether email was sent successfully
   - Any error messages

### Step 5: Try Registration Again

After configuring SMTP, try registering again. The OTP email should now be sent successfully.

## Troubleshooting

### Error: "SMTP credentials not configured"
- **Solution:** You haven't updated the placeholder values in `mail-config.php`

### Error: "Authentication failed"
- **Solution:** 
  - For Gmail: Use App Password, not your regular password
  - Make sure 2-Step Verification is enabled
  - Check that there are no spaces in the app password

### Error: "Connection timeout"
- **Solution:**
  - Check your internet connection
  - Try port 465 with SSL instead of 587 with TLS
  - Check firewall/antivirus settings

### Error: "SMTP connect() failed"
- **Solution:**
  - Verify SMTP_HOST is correct for your provider
  - Check SMTP_PORT matches your provider's requirements
  - Try different encryption (tls vs ssl)

## Important Notes

- **Never commit your actual passwords to version control**
- **Set `SMTP_DEBUG` to `false` in production**
- **Gmail requires App Passwords when 2-Step Verification is enabled**
- **Some email providers block SMTP from unknown locations - you may need to allow "less secure apps" or use App Passwords**
