// home-script.js (Full Updated Code with Multiple Rajkot Restaurant Suggestions)

// ===========================================
// MOODMEAL DATA STRUCTURE (Updated with multiple Rajkot Suggestions)
// ===========================================
const MOOD_MEALS = {
    "Happy": { 
        icon: "fa-face-laugh-beam", 
        color: "#DAA520", // Vibrant Gold
        meals: [
           { name: "Spicy Paneer Tikka Masala", type: "Veg", desc: "A rich, vibrant, and celebratory North Indian classic.", thumb: "https://www.cookwithmanali.com/wp-content/uploads/2014/04/Paneer-Tikka-Masala.jpg", recipe: { ingredients: ["200g Paneer", "1 cup Yogurt", "Ginger-Garlic Paste", "Garlic", "Spices"], steps: ["Marinate paneer for 30 mins.", "Grill/pan-fry until golden.", "Cook sauce with onions and spices.", "Combine and serve hot."] }, 
                suggestions: [
                    { name: "Lords Banquet Restaurant", query: "Lords Banquet Restaurant Rajkot" },
                    { name: "Matuki Restaurant", query: "Matuki Restaurant Rajkot" },
                    { name: "The Imperial Palace", query: "The Imperial Palace Rajkot" },
                ] 
            },
            { name: "Cheesy Stuffed Paratha", type: "Veg", desc: "Golden, crisp flatbread stuffed with cheese and spices.", thumb: "https://www.yellowthyme.com/wp-content/uploads/2024/08/Cheese-paratha-2.jpg", recipe: { ingredients: ["Wheat flour", "200g Cheese/Paneer", "Chilies", "Coriander"], steps: ["Knead dough.", "Stuff with grated cheese and spices.", "Roll and shallow fry with ghee until crisp."], }, 
                suggestions: [
                    { name: "Temptation Restaurant", query: "Temptation Restaurant Rajkot" },
                    { name: "Jassi De Parathe", query: "Jassi De Parathe Rajkot" },
                ] 
            },
            { name: "Chocolate Lava Cake", type: "Veg", desc: "Pure indulgence and a rush of happiness.", thumb: "https://insanelygoodrecipes.com/wp-content/uploads/2024/12/Lava-Cake-2.jpg", recipe: { ingredients: ["100g Dark Chocolate", "Butter", "Eggs", "Sugar", "Flour"], steps: ["Melt chocolate and butter.", "Mix ingredients.", "Bake for 12-14 mins until edges are firm."], }, 
                suggestions: [
                    { name: "The Chocolate Room", query: "The Chocolate Room Rajkot" },
                    { name: "Theobroma", query: "Theobroma Rajkot" },
                    { name: "Creamzen", query: "Creamzen Rajkot" },
                ] 
            },
            { name: "Chana Bhatura", type: "Veg", desc: "Fluffy fried bread with spicy chickpea curry.", thumb: "https://previews.123rf.com/images/espies/espies2212/espies221200160/195548065-chole-bhature-is-a-north-indian-food-dish-a-combination-of-chana-masala-and-bhatura-or-puri.jpg", recipe: { ingredients: ["Refined flour", "Yogurt", "Chickpeas", "Tamarind", "Spices"], steps: ["Knead dough with yogurt and rest.", "Boil chickpeas and cook in gravy.", "Deep fry the dough to make bhatura."], }, 
                suggestions: [
                    { name: "Mehul's Kitchen", query: "Mehul's Kitchen Chole Bhature Rajkot" },
                    { name: "Chetna Restaurant", query: "Chetna Restaurant Rajkot" },
                ] 
            },
            { name: "Gajar Halwa", type: "Veg", desc: "Warm, traditional carrot dessert.", thumb: "https://greedyeats.com/wp-content/uploads/2023/08/Carrot-Halwa.jpg", recipe: { ingredients: ["Grated Carrots", "Milk", "Ghee", "Sugar", "Cardamom"], steps: ["Roast carrots in ghee.", "Add milk and cook until reduced.", "Add sugar, cardamom, and nuts."], }, 
                suggestions: [
                    { name: "Santushti Shakes", query: "Santushti Shakes Rajkot" },
                    { name: "Dessert Hub", query: "Dessert Hub Rajkot" },
                ] 
            },
            { name: "Chicken Biryani with Raita", type: "Non-Veg", desc: "Aromatic rice and tender chicken—perfect for sharing joy.", thumb: "https://upload.wikimedia.org/wikipedia/commons/2/2f/Biryani_and_Raita.jpg", recipe: { ingredients: ["Basmati Rice", "Chicken pieces", "Yogurt", "Saffron", "Spices"], steps: ["Marinate chicken.", "Layer partially cooked rice and chicken.", "Cook on low heat (dum method)."], }, 
                suggestions: [
                    { name: "Biryani By Kilo", query: "Biryani By Kilo Rajkot" },
                    { name: "Shahi Darbar", query: "Shahi Darbar Rajkot" },
                    { name: "SK Restaurant", query: "SK Restaurant Rajkot" },
                ] 
            },
            { name: "Butter Chicken with Naan", type: "Non-Veg", desc: "Creamy, savory, and satisfying comfort food.", thumb: "https://masalaandchai.com/wp-content/uploads/2022/03/Butter-Chicken.jpg", recipe: { ingredients: ["Chicken breast", "Tomato puree", "Cream", "Butter", "Honey", "Kasuri Methi"], steps: ["Grill marinated chicken.", "Simmer in rich tomato-cream sauce.", "Serve with fresh buttered naan."], }, 
                suggestions: [
                    { name: "House of Size Zero", query: "House of Size Zero Rajkot" },
                    { name: "The Imperial Palace", query: "The Imperial Palace Rajkot" },
                    { name: "Hot and More Restaurant", query: "Hot and More Restaurant Rajkot" },
                ] 
            },
            { name: "Prawn Curry (Kolhapuri Style)", type: "Non-Veg", desc: "Fiery and bold seafood dish to amplify your mood.", thumb: "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjFi0bDjJk4LxhOTsU8iIIKznOLd0cnm6x2QkWejIb_JQOrl2MrkoeV0xyzDoebMrY6Kfrw2MGbh969WTKXXdetZlRvukyqfMX_pa2J1EkWfIg9NXdIgWEXLwMQDN7amjFtlxQsQHTT7Y14/s1600/kolhapuri-prawn-masala13.jpg", recipe: { ingredients: ["Fresh Prawns", "Coconut milk", "Red Chilies", "Kolhapuri Masala"], steps: ["Sauté masala and onions.", "Add coconut milk and prawns.", "Simmer until prawns are cooked."], }, 
                suggestions: [
                    { name: "Royal Rajputana", query: "Royal Rajputana Restaurant Rajkot" },
                    { name: "Surti Egg Masti", query: "Surti Egg Masti Rajkot" },
                ] 
            },
            { name: "Spicy Beef Vindaloo", type: "Non-Veg", desc: "A hot, tangy, and complex Portuguese-Indian classic.", thumb: "https://www.chilipeppermadness.com/wp-content/uploads/2022/12/Beef-Vindaloo-Recipe1-2022.jpg", recipe: { ingredients: ["Beef Cubes", "Vinegar", "Red Chilies", "Cumin", "Garlic"], steps: ["Marinate beef in vindaloo paste overnight.", "Slow cook until meat is fork-tender.", "Serve hot with rice."], }, 
                suggestions: [
                    { name: "Mahashakti Rajputana", query: "Mahashakti Rajputana Rajkot" },
                    { name: "Jay hind Hotel", query: "Jay hind Hotel Rajkot" },
                ] 
            },
            { name: "Lamb Kebabs", type: "Non-Veg", desc: "Grilled, spiced skewers for instant gratification.", thumb: "https://overthefirecooking.com/wp-content/uploads/2022/04/A_IMG_1613-2-scaled.jpg", recipe: { ingredients: ["Ground Lamb/Mutton", "Ginger", "Chilies", "Mint", "Onion"], steps: ["Mix all ingredients and form kebabs.", "Grill or pan-fry until charred and cooked through.", "Serve with mint chutney."], }, 
                suggestions: [
                    { name: "Barbeque Nation", query: "Barbeque Nation Rajkot" },
                    { name: "The Babji's Grill", query: "The Babji's Grill Kitchen Rajkot" },
                    { name: "Huseni Caterers", query: "Huseni Caterers Rajkot" },
                ] 
            }
        ]
    },
    "Sad": {
        icon: "fa-face-frown", 
        color: "#5C7FB7", // Deep Cerulean Blue
        meals: [
            { name: "Masala Khichdi with Ghee", type: "Veg", desc: "Warm, soft, and soothing rice-lentil porridge.", thumb: "https://www.funfoodfrolic.com/wp-content/uploads/2022/07/Masala-Khichdi-2.jpg", recipe: { ingredients: ["Rice", "Yellow lentils", "Vegetables", "Turmeric"], steps: ["Mix and wash rice and lentils.", "Pressure cook with vegetables and spices.", "Serve with a drizzle of ghee."], }, 
                suggestions: [
                    { name: "The Grand Thakar", query: "The Grand Thakar Rajkot" },
                    { name: "Gordhan Thal", query: "Gordhan Thal Rajkot" },
                    { name: "Great Indian Khichdi", query: "Great Indian Khichdi Rajkot" },
                ] 
            },
            { name: "Rajma Chawal (Kidney Beans Curry)", type: "Veg", desc: "Soul food—heavy, creamy, and deeply satisfying.", thumb: "https://www.cookwithmanali.com/wp-content/uploads/2014/10/Rajma-Kidney-Beans-Curry-1014x1536.jpg", recipe: { ingredients: ["Kidney Beans (Rajma)", "Tomatoes", "Onions", "Cream", "Rice"], steps: ["Soak rajma overnight and boil.", "Cook tomato-onion gravy.", "Simmer rajma until creamy and serve with rice."], }, 
                suggestions: [
                    { name: "Amritsar Haveli", query: "Amritsar Haveli Rajkot" },
                    { name: "Pandeyji Parcel Point", query: "Pandeyji Parcel Point Rajkot" },
                    { name: "The Grand Thakar", query: "The Grand Thakar Rajkot" },
                ] 
            },
            { name: "Aloo Paratha with Curd", type: "Veg", desc: "Filling, homely, and reminds you of mother's cooking.", thumb: "https://upload.wikimedia.org/wikipedia/commons/3/37/Aloo_Paratha_with_curd_and_Pickle.jpg", recipe: { ingredients: ["Wheat flour", "Potatoes (Aloo)", "Spices", "Yogurt"], steps: ["Boil and mash potatoes with spices.", "Stuff in wheat dough and roll.", "Shallow fry and serve with curd."], }, 
                suggestions: [
                    { name: "Temptation Restaurant", query: "Temptation Restaurant Rajkot" },
                    { name: "Amrut Restaurant", query: "Amrut Restaurant Rajkot" },
                ] 
            },
            { name: "Daal Baati Churma", type: "Veg", desc: "Traditional Rajasthani comfort, heavy and rich.", thumb: "https://upload.wikimedia.org/wikipedia/commons/a/af/%22Delectable_Dal_Baati_Churma%22.jpg", recipe: { ingredients: ["Assorted Daals", "Wheat flour (for Baati)", "Ghee", "Jaggery"], steps: ["Bake/roast baati (round dough).", "Cook daal.", "Crush churma (sweetened baati) and serve with daal."], }, 
                suggestions: [
                    { name: "Gir Gamthi Kathiyawadi", query: "Gir Gamthi Kathiyawadi Zayka Rajkot" },
                    { name: "Suryakant Restaurant", query: "Suryakant Restaurant Rajkot" },
                    { name: "Kathiyawadi Jalsa", query: "Kathiyawadi Jalsa Rajkot" },
                ] 
            },
            { name: "Vegetable Upma", type: "Veg", desc: "Soft, light semolina savory dish.", thumb: "https://myfoodstory.com/wp-content/uploads/2022/11/Vegetable-Upma-2.jpg", recipe: { ingredients: ["Semolina (Rava)", "Mustard seeds", "Curry leaves", "Vegetables"], steps: ["Roast rava.", "Sauté tempering spices and vegetables.", "Add water and rava; cook until thickened."], }, 
                suggestions: [
                    { name: "Jayhind Madras Cafe", query: "Jayhind Madras Cafe Rajkot" },
                    { name: "22nd Parallel", query: "22nd Parallel South Indian Rajkot" },
                    { name: "Dosa Hub", query: "Dosa Hub Rajkot" },
                ] 
            },
            { name: "Chicken Soup (Immunity Booster)", type: "Non-Veg", desc: "A classic warm broth for physical and emotional comfort.", thumb: "https://www.theroastedroot.net/wp-content/uploads/2023/03/immunity-boosting-turmeric-chicken-soup-recipe-3.jpg", recipe: { ingredients: ["Chicken Bones/Stock", "Carrots", "Celery", "Herbs"], steps: ["Boil chicken and veggies for 1 hour.", "Strain broth and season.", "Add shredded chicken."], }, 
                suggestions: [
                    { name: "House of Size Zero", query: "House of Size Zero Rajkot" },
                    { name: "Hot and More Restaurant", query: "Hot and More Restaurant Rajkot" },
                ] 
            },
            { name: "Fish Fry (South Indian style)", type: "Non-Veg", desc: "Crispy, spicy protein for a quick mood lift.", thumb: "https://www.masalakorb.com/wp-content/uploads/2015/04/Spicy-South-Indian-Style-Fish-Fry-V1.jpg", recipe: { ingredients: ["Fish fillets", "Chili powder", "Lemon juice", "Ginger-garlic paste"], steps: ["Marinate fish in spice paste.", "Shallow fry until crisp and golden brown.", "Serve with onion rings."], }, 
                suggestions: [
                    { name: "Surti Egg Masti (Seafood)", query: "Surti Egg Masti Rajkot" },
                    { name: "Lesange Grill", query: "Lesange Grill Rajkot" },
                ] 
            },
            { name: "Lamb Stew with Rice", type: "Non-Veg", desc: "Slow-cooked, tender lamb for deep, lasting warmth.", thumb: "https://thewoksoflife.com/wp-content/uploads/2015/11/goat-stew-9.jpg", recipe: { ingredients: ["Lamb Cubes", "Potatoes", "Carrots", "Rosemary", "Wine/Stock"], steps: ["Brown the lamb.", "Add vegetables and stock.", "Slow cook until lamb is tender."], }, 
                suggestions: [
                    { name: "Barbeque Nation", query: "Barbeque Nation Rajkot" },
                    { name: "SK Restaurant", query: "SK Restaurant Rajkot" },
                ] 
            },
            { name: "Pork Chops with Gravy", type: "Non-Veg", desc: "A substantial, filling meal to provide comfort.", thumb: "https://www.allrecipes.com/thmb/vXWSBiI8Oi8t5mqT2ti-MRWp-kQ=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/277708-southern-smothered-pork-chops-in-brown-gravy-DDMFS-4x3-1-ba69c8e7138c48beb9675843ed44a69a.jpg", recipe: { ingredients: ["Pork Chops", "Sage", "Apple cider", "Butter", "Flour"], steps: ["Sear chops.", "Deglaze pan with cider and make gravy.", "Bake or fry chops until done."], }, 
                suggestions: [
                    { name: "Royal Rajputana", query: "Royal Rajputana Restaurant Rajkot" },
                    { name: "Mahashakti Rajputana", query: "Mahashakti Rajputana Rajkot" },
                ] 
            },
            { name: "Keema Pav", type: "Non-Veg", desc: "Spiced minced meat curry served with soft bread.", thumb: "https://upload.wikimedia.org/wikipedia/commons/2/26/Keema_Pao_with_Hari_Chutney.jpg", recipe: { ingredients: ["Ground Mutton/Chicken", "Ginger", "Green peas", "Pav Bhaji Masala", "Buns (Pav)"], steps: ["Cook minced meat with spices.", "Add peas and simmer.", "Serve with buttered and toasted pav."], }, 
                suggestions: [
                    { name: "Bombay Street Food", query: "Bombay Street Food Rajkot" },
                    { name: "Hot and More Restaurant", query: "Hot and More Restaurant Rajkot" },
                ] 
            }
        ]
    },
    "Stressed": { 
        icon: "fa-face-tired", 
        color: "#800080", // Deep Purple
        meals: [
            { name: "Lemon Rice", type: "Veg", desc: "Light...", thumb: "https://www.cookwithmanali.com/wp-content/uploads/2016/01/South-Indian-Lemon-Rice-Recipe-1200x1818.jpg", recipe: { ingredients: ["Rice", "Lemon juice", "Curry leaves"], steps: ["Cook rice.", "Temper spices.", "Mix and serve."] }, 
                suggestions: [
                    { name: "Jayhind Madras Cafe", query: "Jayhind Madras Cafe Rajkot" },
                    { name: "The Grand Thakar", query: "The Grand Thakar Rajkot" },
                ] 
            }, 
            { name: "Mint Chia Seed Pudding", type: "Veg", desc: "Cooling...", thumb: "https://choosingchia.com/jessh-jessh/uploads/2016/04/matcha-mint-chocolate-chia-pudding-3.jpg", recipe: { ingredients: ["Chia seeds", "Milk", "Mint", "Honey"], steps: ["Mix all ingredients.", "Refrigerate overnight.", "Serve chilled."] }, 
                suggestions: [
                    { name: "Juice N Shakes JNS", query: "Juice N Shakes JNS Rajkot" },
                    { name: "Santushti Shakes", query: "Santushti Shakes Rajkot" },
                ] 
            }, 
            { name: "Vegetable Poha", type: "Veg", desc: "A light, healthy breakfast option that won't overwhelm.", thumb: "https://www.mrishtanna.com/wp-content/uploads/2018/04/vegetable-poha-recipe-1.jpg", recipe: { ingredients: ["Poha", "Onions", "Potatoes", "Mustard seeds"], steps: ["Wash poha.", "Sauté tempering and veggies.", "Add poha and cook."] }, 
                suggestions: [
                    { name: "Anand Snacks", query: "Anand Snacks Rajkot" },
                    { name: "Shri Hari Poha", query: "Shri Hari Poha Rajkot" },
                ] 
            }, 
            { name: "Cucumber & Mint Raita", type: "Veg", desc: "Cooling Indian yogurt dip to calm the system.", thumb: "https://www.nourishandtempt.com/wp-content/uploads/2023/10/66FE2BE3-1758-4813-B086-1719799793ED.jpg", recipe: { ingredients: ["Yogurt", "Grated cucumber", "Mint", "Cumin powder"], steps: ["Whisk yogurt.", "Add cucumber and mint.", "Season and serve chilled."] }, 
                suggestions: [
                    { name: "The Grand Thakar", query: "The Grand Thakar Rajkot" },
                    { name: "Matuki Restaurant", query: "Matuki Restaurant Rajkot" },
                ] 
            }, 
            { name: "Plain Idli Sambhar", type: "Veg", desc: "Steamed, fermented rice cakes—very easy to digest.", thumb: "https://www.shutterstock.com/shutterstock/photos/1883781856/display_1500/stock-photo-idly-sambar-or-idli-with-sambhar-and-green-red-chutney-popular-south-indian-breakfast-1883781856.jpg", recipe: { ingredients: ["Idli batter", "Lentils (Sambhar)", "Vegetables"], steps: ["Steam idlis.", "Prepare sambhar (lentil soup).", "Serve hot with chutney."] }, 
                suggestions: [
                    { name: "Jayhind Madras Cafe", query: "Jayhind Madras Cafe Rajkot" },
                    { name: "Sankalp", query: "Sankalp Rajkot" },
                    { name: "22nd Parallel", query: "22nd Parallel South Indian Rajkot" },
                ] 
            }, 
            { name: "Tuna Salad Sandwich (with whole grain bread)", type: "Non-Veg", desc: "Simple, easy-to-prepare meal rich in Omega-3s.", thumb: "https://simplyhomecooked.com/wp-content/uploads/2024/03/tuna-sandwich-recipe.jpg", recipe: { ingredients: ["Canned Tuna", "Mayonnaise", "Celery", "Whole Grain Bread"], steps: ["Mix tuna, mayo, and celery.", "Spread on toasted bread.", "Serve with a side of chips."] }, 
                suggestions: [
                    { name: "Subway", query: "Subway Rajkot 150 Feet Ring Road" },
                    { name: "Dazzling Dubai", query: "Dazzling Dubai Rajkot" },
                ] 
            }, 
            { name: "Grilled Chicken & Steamed Veggies", type: "Non-Veg", desc: "Lean protein and light greens for sustained energy without the crash.", thumb: "https://www.shutterstock.com/shutterstock/photos/579311821/display_1500/stock-photo-grilled-chicken-with-steamed-vegetables-579311821.jpg", recipe: { ingredients: ["Chicken breast", "Broccoli", "Olive oil", "Seasoning"], steps: ["Grill chicken until cooked.", "Steam vegetables.", "Serve with light seasoning."] }, 
                suggestions: [
                    { name: "Michi's Restaurant", query: "Michi's Restaurant Rajkot" },
                    { name: "House of Size Zero", query: "House of Size Zero Rajkot" },
                ] 
            }, 
            { name: "Salmon with Asparagus", type: "Non-Veg", desc: "High in stress-reducing Omega-3s.", thumb: "https://reneenicoleskitchen.com/wp-content/uploads/2017/03/Lemon-Dill-Salmon-and-Asparagus-Image-1.jpg", recipe: { ingredients: ["Salmon fillet", "Asparagus", "Lemon", "Garlic", "Butter"], steps: ["Bake salmon with lemon and butter.", "Roast asparagus.", "Serve with rice."] }, 
                suggestions: [
                    { name: "The Imperial Palace", query: "The Imperial Palace Rajkot" },
                    { name: "Apple Bite", query: "Apple Bite Multi Cuisine Rajkot" },
                ] 
            }, 
            { name: "Turkey and Lettuce Wrap", type: "Non-Veg", desc: "Extremely light and easy to digest, low carbohydrate.", thumb: "https://www.allrecipes.com/thmb/JOecU0mIcIAXiPxguRmisRalcag=/0x512/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/270054ground-turkey-lettuce-wrapsFranceC4x3-eb927d7ba68d4dd6847b8b43b1865ad1.jpg", recipe: { ingredients: ["Turkey slices", "Lettuce", "Cream cheese", "Tomato"], steps: ["Spread cream cheese on turkey.", "Roll up with veggies in lettuce.", "Serve immediately."] }, 
                suggestions: [
                    { name: "Subway", query: "Subway Rajkot" },
                    { name: "Dazzling Dubai", query: "Dazzling Dubai Rajkot" },
                ] 
            }, 
            { name: "Chicken and Brown Rice", type: "Non-Veg", desc: "Simple, nutrient-dense meal for stable energy.", thumb: "https://www.shutterstock.com/shutterstock/photos/2534889583/display_1500/stock-photo-grilled-chicken-breast-with-brown-rice-spinach-broccoli-asparagus-concept-of-diet-healthy-2534889583.jpg", recipe: { ingredients: ["Brown Rice", "Chicken breast", "Soya sauce", "Ginger"], steps: ["Cook brown rice.", "Stir-fry chicken with sauce and ginger.", "Combine and serve hot."] }, 
                suggestions: [
                    { name: "Pandeyji Parcel Point", query: "Pandeyji Parcel Point Rajkot" },
                    { name: "SK Restaurant", query: "SK Restaurant Rajkot" },
                ] 
            }
        ] 
    },
    "Angry": { 
        icon: "fa-face-angry", 
        color: "#E9573E", // Deep Ruby Red
        meals: [
            { name: "Extra Spicy Vada Pav", type: "Veg", desc: "Bite into something aggressively spicy to diffuse tension.", thumb: "https://ministryofcurry.com/wp-content/uploads/2024/06/vada-pav-3.jpg", recipe: { ingredients: ["Potatoes", "Gram flour", "Garlic chutney", "Buns (Pav)"], steps: ["Prepare spicy potato filling.", "Coat in gram flour and fry.", "Serve hot with green chili and garlic chutney."] }, 
                suggestions: [
                    { name: "Ishwarbhai Ghughra", query: "Ishwarbhai Ghughra Wala Rajkot" },
                    { name: "Raj Pavbhaji", query: "Raj Pavbhaji Rajkot" },
                ] 
            }, 
            { name: "Chili Cheese Toast (with green chilies)", type: "Veg", desc: "A satisfyingly sharp, crunchy, and pungent snack.", thumb: "https://shwetainthekitchen.com/wp-content/uploads/2023/02/chili-cheese-toast.jpg", recipe: { ingredients: ["Bread", "Cheese", "Green Chilies", "Butter"], steps: ["Mix cheese, chili, and butter.", "Spread on bread.", "Grill until cheese melts and bubbles."] }, 
                suggestions: [
                    { name: "Delux Sandwich", query: "Delux Sandwich Rajkot" },
                    { name: "Big Bite", query: "Big Bite Rajkot" },
                    { name: "The Street Cafe", query: "The Street Cafe Rajkot" },
                ] 
            }, 
            { name: "Spicy Vegetable Manchurian", type: "Veg", desc: "Indo-Chinese heat to channel strong feelings.", thumb: "https://www.shutterstock.com/image-photo/veg-manchurian-vegetable-balls-dipped-260nw-2490980725.jpg", recipe: { ingredients: ["Cabbage", "Carrots", "Soya sauce", "Chili sauce", "Cornflour"], steps: ["Make vegetable balls.", "Fry until crisp.", "Toss in spicy Manchurian gravy."] }, 
                suggestions: [
                    { name: "Wok On Fire", query: "Wok On Fire Rajkot" },
                    { name: "China Hut", query: "China Hut Rajkot" },
                    { name: "Chili Food Bistro", query: "Chili Food Bistro Rajkot" },
                ] 
            }, 
            { name: "Extra Hot Bhel Puri", type: "Veg", desc: "A mix of textures and explosive flavors.", thumb: "https://shwetainthekitchen.com/wp-content/uploads/2022/01/bhel-puri.jpg", recipe: { ingredients: ["Puffed rice", "Chutneys", "Chilies", "Sev", "Chopped onion"], steps: ["Mix all ingredients just before serving.", "Add extra chili powder for heat.", "Serve immediately."] }, 
                suggestions: [
                    { name: "Chaat Chaska", query: "Chaat Chaska Rajkot" },
                    { name: "Vikrambhai Chavda Food Zone", query: "Vikrambhai Chavda Food Zone Rajkot" },
                ] 
            }, 
            { name: "Jalebi (Sweet contrast)", type: "Veg", desc: "The intense sweetness offers a sudden, satisfying distraction.", thumb: "https://images.news18.com/ibnlive/uploads/2025/09/Jalebi-3-2025-09-16ed59077e61eafcae98aafec438b61f-4x3.jpg", recipe: { ingredients: ["Maida (Flour)", "Yogurt", "Saffron", "Sugar syrup"], steps: ["Ferment batter.", "Fry batter in spiral shapes.", "Dip in warm sugar syrup."] }, 
                suggestions: [
                    { name: "Iscon Gathiya", query: "Iscon Gathiya Rajkot" },
                    { name: "Santushti Shakes", query: "Santushti Shakes Rajkot" },
                ] 
            }, 
            { name: "Tandoori Chicken Wings", type: "Non-Veg", desc: "Something to chew aggressively—high flavor, high protein.", thumb: "https://ministryofcurry.com/wp-content/uploads/2017/02/Tandoori-Chicken-Wings_-2.jpg", recipe: { ingredients: ["Chicken Wings", "Tandoori Masala", "Yogurt", "Lemon"], steps: ["Marinate wings for 4 hours.", "Bake or grill until charred and cooked.", "Serve with onion and lemon."] }, 
                suggestions: [
                    { name: "The Babji's Grill", query: "The Babji's Grill Kitchen Rajkot" },
                    { name: "SK Restaurant", query: "SK Restaurant Rajkot" },
                    { name: "Barbeque Nation", query: "Barbeque Nation Rajkot" },
                ] 
            }, 
            { name: "Mutton Rogan Josh (Extra Hot)", type: "Non-Veg", desc: "Deeply flavorful and intense stew to match the intensity.", thumb: "https://www.licious.in/blog/wp-content/uploads/2020/12/Mutton-Rogan-Josh.jpg", recipe: { ingredients: ["Mutton pieces", "Kashmiri chilies", "Ginger powder", "Fennel powder", "Yogurt"], steps: ["Sear mutton.", "Cook in hot spice paste and yogurt.", "Simmer until tender."], }, 
                suggestions: [
                    { name: "The Imperial Palace", query: "The Imperial Palace Rajkot" },
                    { name: "Karim's", query: "Karim's Rajkot" },
                ] 
            }, 
            { name: "Buffalo Chicken Dip", type: "Non-Veg", desc: "Spicy, creamy, and satisfyingly indulgent.", thumb: "https://www.oliveandmango.com/images/uploads/2022_02_13_buffalo_chicken_dip_2.jpg", recipe: { ingredients: ["Shredded Chicken", "Cream cheese", "Hot Sauce", "Ranch dressing", "Blue cheese"], steps: ["Mix all ingredients and bake until bubbly.", "Serve hot with tortilla chips or celery."] }, 
                suggestions: [
                    { name: "Burger King", query: "Burger King Rajkot" },
                    { name: "Burger Singh", query: "Burger Singh Rajkot" },
                ] 
            }, 
            { name: "Spicy Seafood Tacos", type: "Non-Veg", desc: "Bold, fresh, and demands full attention.", thumb: "https://minimalistbaker.com/wp-content/uploads/2020/03/SPICY-Baked-Fish-Tacos-30-minutes-simple-ingredients-BIG-FLAVOR-glutenfree-recipe-fish-tacos-minimalistbaker-8.jpg", recipe: { ingredients: ["Fish/Shrimp", "Tortillas", "Chili powder", "Cabbage slaw", "Lime"], steps: ["Season and cook seafood.", "Warm tortillas.", "Assemble tacos with slaw and sauce."], }, 
                suggestions: [
                    { name: "Taco Bout It", query: "Taco Bout It Rajkot" },
                    { name: "China Hut", query: "China Hut Rajkot" },
                ] 
            }, 
            { name: "Chili Garlic Prawns", type: "Non-Veg", desc: "Sharp garlic and chili hit to cut through anger.", thumb: "https://www.recipetineats.com/tachyon/2016/07/Asian-Chilli-Garlic-Prawns-1_5.jpg", recipe: { ingredients: ["Prawns", "Garlic", "Dried red chilies", "Soya sauce"], steps: ["Stir-fry garlic and chilies.", "Add prawns and sauces.", "Cook quickly until prawns are pink."] }, 
                suggestions: [
                    { name: "Wok On Fire", query: "Wok On Fire Rajkot" },
                    { name: "China Hut", query: "China Hut Rajkot" },
                ] 
            }
        ] 
    },
    "Excited": { 
        icon: "fa-face-grin-stars", 
        color: "#FF9900", // Bright Orange/Amber
        meals: [
            { name: "Loaded Veggie Pizza", type: "Veg", desc: "Fun, celebratory, and customizable party food.", thumb: "https://i.pinimg.com/736x/7d/a7/b1/7da7b18d0e597dee281a899842d7d2f7.jpg", recipe: { ingredients: ["Pizza Dough", "Tomato sauce", "Mozzarella", "Assorted veggies"], steps: ["Roll out dough and spread sauce.", "Load with cheese and toppings.", "Bake until crust is golden."], }, 
                suggestions: [
                    { name: "Pizzaiiolo", query: "Pizzaiiolo - The Wood Fired Pizza Rajkot" },
                    { name: "La Pino'z Pizza", query: "La Pino'z Pizza Rajkot" },
                    { name: "Domino's Pizza", query: "Domino's Pizza Rajkot" },
                ] 
            }, 
            { name: "Falafel Wrap with Hummus", type: "Veg", desc: "Fresh, zesty, and easy to eat while moving.", thumb: "https://www.vibrantplate.com/wp-content/uploads/2019/09/Falafel-04.jpg", recipe: { ingredients: ["Chickpeas", "Pita bread", "Hummus", "Tahini sauce", "Lettuce"], steps: ["Fry falafel.", "Spread hummus on pita.", "Load with falafel and salad and wrap."], }, 
                suggestions: [
                    { name: "Subway", query: "Subway 150 Feet Ring Road Rajkot" },
                    { name: "Dazzling Dubai", query: "Dazzling Dubai Rajkot" },
                ] 
            }, 
            { name: "Chilled Fruit Chaat (Seasonal)", type: "Veg", desc: "Light, zesty, and easy to share the excitement.", thumb: "https://www.shutterstock.com/image-photo/bowl-colorful-flavor-fruit-chat-600w-2529614935.jpg", recipe: { ingredients: ["Seasonal fruits (apples, grapes, banana)", "Chaat masala", "Lemon juice"], steps: ["Chop fruits.", "Toss with chaat masala and lemon juice.", "Serve chilled."] }, 
                suggestions: [
                    { name: "Juice N Shakes JNS", query: "Juice N Shakes JNS Rajkot" },
                    { name: "Santushti Shakes", query: "Santushti Shakes Rajkot" },
                ] 
            }, 
            { name: "Veggie Burgers", type: "Veg", desc: "A crowd-pleasing, fun, and casual choice.", thumb: "https://images.immediate.co.uk/production/volatile/sites/30/2020/10/Secret-Veg-Cheeseburgers-c981dd6.jpg", recipe: { ingredients: ["Veggie patties", "Burger buns", "Lettuce", "Tomato", "Sauce"], steps: ["Grill patties.", "Toast buns.", "Assemble burger with fresh toppings and sauce."] }, 
                suggestions: [
                    { name: "Burger King", query: "Burger King Kalawad Road Rajkot" },
                    { name: "Burger It Up", query: "Burger It Up Rajkot" },
                ] 
            }, 
            { name: "Vegetable Spring Rolls", type: "Veg", desc: "Crispy, savory finger food perfect for a lively mood.", thumb: "https://d1mxd7n691o8sz.cloudfront.net/static/recipe/recipe/2023-12/Vegetable-Spring-Rolls-2-1-906001560ca545c8bc72baf473f230b4.jpg", recipe: { ingredients: ["Spring roll wrappers", "Shredded vegetables", "Soya sauce"], steps: ["Sauté vegetables.", "Wrap filling in wrappers.", "Deep fry until golden and crisp."] }, 
                suggestions: [
                    { name: "Wok On Fire", query: "Wok On Fire Rajkot" },
                    { name: "Chili Food Bistro", query: "Chili Food Bistro Rajkot" },
                ] 
            }, 
            { name: "Spicy Chicken Tacos", type: "Non-Veg", desc: "Interactive, vibrant, and fun to assemble.", thumb: "https://www.sprinklesandsprouts.com/wp-content/uploads/2024/09/Spicy-Chicken-Tacos-SQ.jpg", recipe: { ingredients: ["Chicken breast", "Taco shells", "Salsa", "Cheese", "Taco seasoning"], steps: ["Cook and season chicken.", "Warm taco shells.", "Assemble tacos with toppings and sour cream."] }, 
                suggestions: [
                    { name: "Taco Bout It", query: "Taco Bout It Rajkot" },
                    { name: "Amigos Restaurant", query: "Amigos Restaurant Rajkot" },
                ] 
            }, 
            { name: "Shrimp Scampi Pasta", type: "Non-Veg", desc: "Elegant, flavorful, and celebratory seafood dish.", thumb: "https://cookingwithcocktailrings.com/wp-content/uploads/2023/08/Summer-Shrimp-Scampi-Pasta-37-scaled.jpg", recipe: { ingredients: ["Shrimp", "Linguine pasta", "Garlic", "Lemon", "White wine/stock"], steps: ["Cook pasta.", "Sauté shrimp in garlic and butter.", "Deglaze with wine and toss with pasta."] }, 
                suggestions: [
                    { name: "The Imperial Palace", query: "The Imperial Palace Rajkot" },
                    { name: "Apple Bite", query: "Apple Bite Multi Cuisine Rajkot" },
                ] 
            }, 
            { name: "BBQ Pulled Pork Sliders", type: "Non-Veg", desc: "Messy, delicious, and easy party food.", thumb: "https://shop.woodlandfoods.com/img/WF_Images/h424-bbq-pulled-pork-sliders-1.jpg", recipe: { ingredients: ["Pork shoulder", "BBQ sauce", "Slider buns", "Coleslaw"], steps: ["Slow cook pork until shreddable.", "Mix with BBQ sauce.", "Serve on buns with coleslaw."] }, 
                suggestions: [
                    { name: "Barbeque Nation", query: "Barbeque Nation Rajkot" },
                    { name: "The Babji's Grill", query: "The Babji's Grill Kitchen Rajkot" },
                ] 
            }, 
            { name: "Chicken and Waffles", type: "Non-Veg", desc: "Sweet and savory combination for maximum fun.", thumb: "https://www.butterbeready.com/wp-content/uploads/2022/05/DK6A0247.jpg", recipe: { ingredients: ["Fried Chicken", "Waffle batter", "Syrup", "Butter"], steps: ["Prepare and fry chicken.", "Cook waffles.", "Stack and serve with syrup and butter."] }, 
                suggestions: [
                    { name: "The Belgian Waffle Co.", query: "The Belgian Waffle Co. Rajkot" },
                    { name: "Cube Lounge", query: "Cube Lounge Rajkot" },
                ] 
            }, 
            { name: "Seafood Paella", type: "Non-Veg", desc: "A colorful, communal dish for a lively mood.", thumb: "https://assets.epicurious.com/photos/63ef9f657c3e98834ec8645e/1:1/w_2560%2Cc_limit/Paella_RECIPE_021523_47427.jpg", recipe: { ingredients: ["Arborio Rice", "Saffron", "Shrimp", "Mussels", "Peppers"], steps: ["Sauté vegetables and seafood.", "Add rice and saffron stock.", "Cook slowly until rice is done."] }, 
                suggestions: [
                    { name: "The Imperial Palace", query: "The Imperial Palace Rajkot" },
                    { name: "Royal Rajputana", query: "Royal Rajputana Restaurant Rajkot" },
                ] 
            }
        ] 
    },
    "Relaxed": { 
        icon: "fa-face-smile", 
        color: "#8AAF6B", // Rich Emerald Green
        meals: [
            { name: "Coconut Water and Seasonal Fruits", type: "Veg", desc: "Light, hydrating, and naturally sweet—easy on the senses.", thumb: "https://static.toiimg.com/thumb/msid-82063460,width-400,resizemode-4/82063460.jpg", recipe: { ingredients: ["Coconut water", "Seasonal fruits (mango, berries)", "Mint"], steps: ["Chill coconut water.", "Chop fruits.", "Combine and serve immediately."] }, 
                suggestions: [
                    { name: "Juice N Shakes JNS", query: "Juice N Shakes JNS Rajkot" },
                    { name: "Santushti Shakes", query: "Santushti Shakes Rajkot" },
                ] 
            }, 
            { name: "Palak Paneer with Basmati Rice", type: "Veg", desc: "A mellow, healthy, and subtly spiced green curry.", thumb: "https://profusioncurry.com/wp-content/uploads/2020/05/Easy-Palak-Paneer-Recipe-a-dinner-plate-with-palak-paneer-naan-and-basmati-rice.jpg", recipe: { ingredients: ["Spinach (Palak)", "Paneer (Cottage Cheese)", "Cream", "Basmati Rice"], steps: ["Blanch and puree spinach.", "Sauté paneer and spices.", "Combine with cream and serve with rice."] }, 
                suggestions: [
                    { name: "Pandeyji Parcel Point", query: "Pandeyji Parcel Point Rajkot" },
                    { name: "Matuki Restaurant", query: "Matuki Restaurant Rajkot" },
                    { name: "Amrut Restaurant", query: "Amrut Restaurant Rajkot" },
                ] 
            }, 
            { name: "Lemon Coriander Soup", type: "Veg", desc: "Clean, clear, and fragrant—ideal for peaceful reflection.", thumb: "https://www.indianveggiedelight.com/wp-content/uploads/2020/03/lemon-coriander-soup-featured.jpg", recipe: { ingredients: ["Vegetable stock", "Lemon juice", "Coriander", "Ginger"], steps: ["Boil stock with ginger.", "Add lemon and coriander.", "Simmer gently and serve."] }, 
                suggestions: [
                    { name: "Giriraj Multicuisine", query: "Giriraj Multicuisine Restaurant Rajkot" },
                    { name: "Chetna Restaurant", query: "Chetna Restaurant Rajkot" },
                ] 
            }, 
            { name: "Tofu Scramble with Turmeric", type: "Veg", desc: "A gentle, warming, and protein-rich breakfast.", thumb: "https://www.heynutritionlady.com/wp-content/uploads/2014/09/Tofu-Scramble-SQ.jpg", recipe: { ingredients: ["Tofu", "Turmeric", "Black salt", "Nutritional yeast"], steps: ["Crumble tofu.", "Sauté with spices (turmeric for color).", "Serve hot with whole-wheat toast."] }, 
                suggestions: [
                    { name: "Anand Snacks", query: "Anand Snacks Rajkot" },
                    { name: "House of Size Zero", query: "House of Size Zero Rajkot" },
                ] 
            }, 
            { name: "Herbal Tea and Biscuits", type: "Veg", desc: "Simple, warm, and comforting for quiet moments.", thumb: "https://www.shutterstock.com/image-photo/herbal-tea-cookies-260nw-466573802.jpg", recipe: { ingredients: ["Chamomile/Green Tea bags", "Honey", "Digestive biscuits"], steps: ["Steep tea bag.", "Add honey.", "Serve with two simple biscuits."] }, 
                suggestions: [
                    { name: "Tea Post", query: "Tea Post Rajkot" },
                    { name: "Cha Vala", query: "Cha Vala Rajkot" },
                ] 
            }, 
            { name: "Poached Eggs on Toast (with Avocado)", type: "Non-Veg", desc: "Simple, gentle flavors for a calm morning or evening.", thumb: "https://nomoneynotime.com.au/uploads/recipes/shutterstock_1926492050-1.jpg", recipe: { ingredients: ["Eggs", "Bread", "Vinegar", "Avocado", "Salt/Pepper"], steps: ["Poach eggs carefully.", "Toast bread and mash avocado.", "Assemble and serve."] }, 
                suggestions: [
                    { name: "Subway", query: "Subway Rajkot" },
                    { name: "Hot and More Restaurant", query: "Hot and More Restaurant Rajkot" },
                ] 
            }, 
            { name: "Tenderloin Steak (medium rare)", type: "Non-Veg", desc: "A perfect, uncomplicated, and deeply satisfying indulgence.", thumb: "https://selfproclaimedfoodie.com/wp-content/uploads/filet-mignon-11.jpg", recipe: { ingredients: ["Tenderloin steak", "Butter", "Garlic", "Thyme", "Salt/Pepper"], steps: ["Season and sear steak.", "Baste with butter/garlic.", "Rest and slice."] }, 
                suggestions: [
                    { name: "Apple Bite", query: "Apple Bite Multi Cuisine Rajkot" },
                    { name: "The Imperial Palace", query: "The Imperial Palace Rajkot" },
                ] 
            }, 
            { name: "Light Chicken Salad", type: "Non-Veg", desc: "Fresh, crisp, and protein-rich without being heavy.", thumb: "https://www.licious.in/blog/wp-content/uploads/2020/12/3-Step-Chicken-Salad.jpg", recipe: { ingredients: ["Grilled Chicken", "Mixed Greens", "Cucumber", "Light vinaigrette"], steps: ["Slice grilled chicken.", "Toss greens and chicken with dressing.", "Serve immediately."] }, 
                suggestions: [
                    { name: "House of Size Zero", query: "House of Size Zero Rajkot" },
                    { name: "Dazzling Dubai", query: "Dazzling Dubai Rajkot" },
                ] 
            }, 
            { name: "Oatmeal with Honey and Berries", type: "Veg", desc: "Warm, smooth, and easily digestible.", thumb: "https://images.unsplash.com/photo-1616719881335-513470783a48?ixlib=rb-4.0.3&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=400&h=250&fit=crop", recipe: { ingredients: ["Oats", "Milk/Water", "Honey", "Mixed berries"], steps: ["Cook oats.", "Top with honey and berries.", "Serve warm."] }, 
                suggestions: [
                    { name: "Santushti Shakes", query: "Santushti Shakes Rajkot" },
                    { name: "Juice N Shakes JNS", query: "Juice N Shakes JNS Rajkot" },
                ] 
            }, 
            { name: "Grilled Fish with Herbs", type: "Non-Veg", desc: "Clean flavors and a delicate texture.", thumb: "https://static.vecteezy.com/system/resources/thumbnails/045/704/822/small/golden-grilled-fish-delight-with-fresh-herbs-and-lemon-photo.jpg", recipe: { ingredients: ["White fish fillet", "Dill", "Parsley", "Lemon", "Olive oil"], steps: ["Marinate fish with herbs and oil.", "Grill until flaky.", "Serve with lemon wedges."] }, 
                suggestions: [
                    { name: "Surti Egg Masti (Seafood)", query: "Surti Egg Masti Rajkot" },
                    { name: "The Imperial Palace", query: "The Imperial Palace Rajkot" },
                ] 
            }
        ] 
    }
};

// Global variable to store the currently selected mood
let currentMood = null; 

// ===========================================
// MOOD SELECTOR LOGIC
// ===========================================

function generateMoodButtons() {
    const container = document.getElementById('mood-buttons-container');
    if (!container) return;

    container.innerHTML = '';
    container.className = 'mood-buttons-container d-flex flex-wrap justify-content-center gap-3';

    Object.keys(MOOD_MEALS).forEach(mood => {
        const moodData = MOOD_MEALS[mood];
        const button = document.createElement('button');
        
        button.className = 'mood-btn';
        button.setAttribute('data-mood', mood);
        button.style.setProperty('--mood-color', moodData.color); 
        button.innerHTML = `
            <i class="fas ${moodData.icon}"></i>
            <span>${mood}</span>
        `;
        
        button.addEventListener('click', () => {
            currentMood = mood; 
            displayDietaryFilter(mood);
        });
        container.appendChild(button);
    });
}

function displayDietaryFilter(mood) {
    // Hide any previous action details (recipe or suggestion)
    hideActionDetails();

    const resultsContainer = document.getElementById('mood-results');
    const mealsContainer = document.getElementById('meal-suggestions-container');
    const resultsTitleElement = resultsContainer.querySelector('.results-title');

    // 1. Reset meals container
    mealsContainer.innerHTML = '';
    resultsContainer.style.display = 'block';

    // 2. Set the results title for the filter step
    resultsTitleElement.innerHTML = 
        `🍽️ What type of meal for your <span style="color: ${MOOD_MEALS[mood].color};">${mood}</span> mood?`;

    // 3. Create and inject filter buttons HTML
    
    let filterContainer = document.getElementById('dietary-filter-container');
    if (filterContainer) filterContainer.remove(); 
    
    filterContainer = document.createElement('div');
    filterContainer.id = 'dietary-filter-container';
    filterContainer.className = 'd-flex justify-content-center gap-4 mb-4';
    
    filterContainer.innerHTML = `
        <button class="diet-btn" onclick="renderMealSuggestions('Veg')">
            <i class="fas fa-leaf"></i> Vegetarian
        </button>
        <button class="diet-btn" onclick="renderMealSuggestions('Non-Veg')">
            <i class="fas fa-drumstick-bite"></i> Non-Vegetarian
        </button>
    `;
    
    resultsTitleElement.parentNode.insertBefore(filterContainer, resultsTitleElement.nextSibling);

    // 4. Removed scrolling logic to stay at the current view.
}

function renderMealSuggestions(dietType) {
    if (!currentMood) return; 

    const mealsContainer = document.getElementById('meal-suggestions-container');
    const resultsContainer = document.getElementById('mood-results');
    const meals = MOOD_MEALS[currentMood].meals;

    // Filter meals by the selected diet type
    const filteredMeals = meals.filter(meal => meal.type.startsWith(dietType));

    // Limit to 5 meals
    const mealsToDisplay = filteredMeals.slice(0, 5);

    // Clear filter buttons (now that we have selected)
    const filterContainer = document.getElementById('dietary-filter-container');
    if (filterContainer) filterContainer.remove();
    mealsContainer.innerHTML = '';

    // Update title to show the final filtered result
    resultsContainer.querySelector('.results-title').innerHTML = 
        `🍽️ 5 ${dietType} Meal Ideas for Your <span style="color: ${MOOD_MEALS[currentMood].color};">${currentMood}</span> Mood`;


    // Generate meal cards for the filtered results
    mealsToDisplay.forEach((meal, index) => {
        const col = document.createElement('div');
        col.className = 'col-lg-4 col-md-6';
        
        // Use the mood-specific color for the border accent
        const moodColor = MOOD_MEALS[currentMood].color;
        
        col.innerHTML = `
            <div class="meal-card">
                <div class="meal-image" style="background-image: url('${meal.thumb}');"></div>
                <div class="meal-content">
                    <div class="meal-header" style="border-bottom: 3px solid ${moodColor};">
                        <h4>${meal.name}</h4>
                        <span class="meal-type meal-type-${meal.type.toLowerCase().replace('/', '-')}" style="background-color: ${meal.type.startsWith('Veg') ? '#8AAF6B' : '#E9573E'}; color: #0D1B2A;">
                            ${meal.type}
                        </span>
                    </div>
                    <p class="meal-description">${meal.desc}</p>
                    
                    <div class="d-flex justify-content-between mt-3">
                        <button class="action-btn make-home" onclick="checkLoginAndProceed('recipe', '${currentMood}', '${meal.name}')">
                            <i class="fas fa-utensils"></i> View Recipe
                        </button>
                        <button class="action-btn order-online" onclick="checkLoginAndProceed('order', '${currentMood}', '${meal.name}')">
                            <i class="fas fa-map-marker-alt"></i> Find Nearby
                        </button>
                    </div>
                </div>
            </div>
        `;
        mealsContainer.appendChild(col);
    });
}

// ===========================================
// AUTHENTICATION CHECKER & PROCEEDER
// ===========================================

function isLoggedIn() {
    return sessionStorage.getItem('moodMealSessionToken') !== null;
}

function checkLoginAndProceed(actionType, mood, mealName) {
    if (isLoggedIn()) {
        if (actionType === 'recipe') {
            showRecipe(mood, mealName);
        } else if (actionType === 'order') {
            // FIX: Call the secured function to show restaurant suggestions
            showRestaurantSuggestionsSecured(mood, mealName);
        }
    } else {
        showLoginRequired();
    }
}

function showLoginRequired() {
    const title = "🔐 Action Blocked";
    const contentHTML = `
        <h4 style="color: #E9573E;">You must be logged in to view meal details.</h4>
        <p style="color: #A0AEC0; margin-top: 15px;">
            Please log in or register to access the full details (recipe or nearby restaurants).
        </p>
        <div style="margin-top: 30px;">
            <a href="index.html" class="btn btn-primary" style="background: linear-gradient(135deg, #DAA520, #8AAF6B); color: #0D1B2A; font-weight: 700; padding: 10px 20px;">
                Go to Login / Register
            </a>
        </div>
    `;
    displayActionDetails(title, contentHTML);
}

// ===========================================
// ACTION STEP HANDLERS (RECIPE AND RESTAURANT SUGGESTION)
// ===========================================

function findMealDetails(mood, mealName) {
    const moodData = MOOD_MEALS[mood];
    return moodData.meals.find(meal => meal.name === mealName);
}

function showRecipe(mood, mealName) {
    const meal = findMealDetails(mood, mealName);
    const recipe = meal.recipe;

    let content = `
        <p style="color: #DAA520; font-weight: 600;">Prep Time: 20 mins | Cook Time: 40 mins</p>
        <h4 style="color: #E0E6F0; margin-top: 15px;">Ingredients:</h4>
        <ul style="list-style-type: disc; margin-left: 20px;">
            ${recipe.ingredients.map(ing => `<li>${ing}</li>`).join('')}
        </ul>
        <h4 style="color: #E0E6F0; margin-top: 15px;">Instructions:</h4>
        <ol style="margin-left: 20px;">
            ${recipe.steps.map(step => `<li>${step}</li>`).join('')}
        </ol>
    `;

    displayActionDetails(`Full Recipe: ${meal.name}`, content);
}

// Renamed function to reflect that it is only called when authenticated
function showRestaurantSuggestionsSecured(mood, mealName) {
    const meal = findMealDetails(mood, mealName);
    const suggestions = meal.suggestions;

    let content = `
        <h4 style="color: #E0E6F0; margin-bottom: 20px;">🍽️ Recommended Restaurants for ${meal.name} in Rajkot:</h4>
        <ul style="list-style-type: none; padding-left: 0;">
            ${suggestions.map((suggestion, index) => {
                // FIX: Corrected the template literal error in the mapsUrl generation
                const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(suggestion.query)}`;
                return `
                    <li style="margin-bottom: 15px; background: #0D1B2A; padding: 15px; border-radius: 10px; border-left: 4px solid #DAA520;">
                        <p style="margin: 0; font-size: 1.1rem; color: #DAA520; font-weight: 600;">
                            ${index + 1}. ${suggestion.name}
                        </p>
                        <a href="${mapsUrl}" target="_blank" 
                           style="color: #8AAF6B; text-decoration: none; font-weight: 500; display: inline-block; margin-top: 5px;">
                           <i class="fas fa-external-link-alt"></i> View on Google Maps
                        </a>
                    </li>
                `;
            }).join('')}
        </ul>
        
        <p style="margin-top: 30px; color: #A0AEC0;">
            <i class="fas fa-info-circle" style="color: #E9573E;"></i> 
            These are real-time search suggestions. Click the link to check current availability, ratings, and exact directions.
        </p>
    `;

    displayActionDetails(`Find Nearby: ${meal.name}`, content);
}

function displayActionDetails(title, contentHTML) {
    // Hide the meal results container first
    document.getElementById('mood-results').style.display = 'none';

    // Set content in the action details box
    document.getElementById('action-title').innerHTML = title;
    document.getElementById('action-content').innerHTML = contentHTML;
    document.getElementById('action-details').style.display = 'block';

    // Scroll to the top of the new display box
    document.getElementById('action-details').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function hideActionDetails() {
    document.getElementById('action-details').style.display = 'none';
    document.getElementById('mood-results').style.display = 'block';

    // Scroll back to the meal suggestions
    document.getElementById('mood-results').scrollIntoView({ behavior: 'smooth', block: 'start' });
}


// ===========================================
// EXISTING AUTH & UI LOGIC
// ===========================================

// --- FUNCTION TO HANDLE LOGIN STATUS AND NAV BUTTONS ---
function checkAuthenticationStatus() {
    const sessionToken = sessionStorage.getItem('moodMealSessionToken');
    const authLinkContainer = document.querySelector('.navbar-nav');
    const existingAuthItem = document.querySelector('#auth-links-container');

    if (existingAuthItem) {
        existingAuthItem.remove();
    }

    const newListItem = document.createElement('li');
    newListItem.className = 'nav-item d-flex align-items-center'; 
    newListItem.id = 'auth-links-container'; 

    if (sessionToken) {
        const dashboardLink = document.createElement('a');
        dashboardLink.textContent = 'Dashboard';
        dashboardLink.href = 'dashboard.html';
        dashboardLink.className = 'nav-link'; 
        
        const logoutButton = document.createElement('a');
        logoutButton.textContent = 'Logout';
        logoutButton.href = '#'; 
        // Use the new class 'nav-auth-btn' for subtle styling
        logoutButton.className = 'nav-link nav-auth-btn btn-sm ms-3'; 

        logoutButton.addEventListener('click', function(e) {
            e.preventDefault();
            homePageLogout(); 
        });
        
        newListItem.appendChild(dashboardLink);
        newListItem.appendChild(logoutButton);

    } else {
        const loginLink = document.createElement('a');
        loginLink.textContent = 'Login';
        loginLink.href = 'index.html';
        // Use the new class 'nav-auth-btn' for subtle styling
        loginLink.className = 'nav-link nav-auth-btn btn-sm ms-2';
        
        newListItem.appendChild(loginLink);
    }
    
    if (authLinkContainer) {
        authLinkContainer.appendChild(newListItem);
    }
}

async function homePageLogout() {
    const token = sessionStorage.getItem("moodMealSessionToken");

    if (token) {
        try {
            const API_BASE_URL = window.location.origin + window.location.pathname.replace('home.html', '').replace(/\/+$/, '') + '/api';

            await fetch(`${API_BASE_URL}/logout.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ session_token: token })
            });
        } catch (e) {
            console.error("Server logout failed, clearing local session anyway.", e);
        }
    }
    
    sessionStorage.removeItem("moodMealSessionToken");
    sessionStorage.removeItem("moodMealUser");
    
    window.location.reload(); 
}


// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    checkAuthenticationStatus();
    generateMoodButtons();

    initNavbar();
    initSmoothScrolling();
    initContactForm();
    initBackToTop();
    initMobileMenu();
    // Expose action functions globally for inline HTML buttons
    window.showRecipe = showRecipe;
    window.showRestaurantSuggestions = showRestaurantSuggestionsSecured; // Expose the SECURED function
    window.hideActionDetails = hideActionDetails;
    window.checkLoginAndProceed = checkLoginAndProceed; // Expose checker function
});

// Utility functions (initNavbar, initSmoothScrolling, etc. functions remain the same as the previous response)
function initNavbar() {
    const navbar = document.getElementById('mainNav');
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
    
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    const sections = document.querySelectorAll('section[id]');
    
    window.addEventListener('scroll', function() {
        let current = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            if (window.scrollY >= (sectionTop - 200)) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') && link.getAttribute('href').startsWith('#') && link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });
}

function initSmoothScrolling() {
    const navLinks = document.querySelectorAll('a[href^="#"]');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('href').startsWith('#') && this.getAttribute('href') !== '#') {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                const targetSection = document.querySelector(targetId);
                
                if (targetSection) {
                    const offsetTop = targetSection.offsetTop - 80; 
                    
                    window.scrollTo({
                        top: offsetTop,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
}
// Removed Spotify Integration and Nutritional Mood Meter references from the footer HTML injection logic in the original plan.
// The remaining utility functions are unchanged as they do not directly reference the removed features.
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            showNotification('Thank you! Your message has been sent successfully.', 'success');
            this.reset();
        });
    }
}

function showNotification(message, type = 'info') {
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `<span>${message}</span><button class="notification-close">×</button>`;
    
    notification.style.cssText = `
        position: fixed; top: 20px; right: 20px; 
        background: ${type === 'success' ? '#8AAF6B' : '#E9573E'};
        color: #0D1B2A; padding: 1rem 1.5rem; border-radius: 10px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        z-index: 10000; transform: translateX(400px); transition: transform 0.3s ease;
        font-weight: 600;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => { notification.style.transform = 'translateX(0)'; }, 100);
    
    notification.querySelector('.notification-close').addEventListener('click', () => {
        notification.style.transform = 'translateX(400px)';
        setTimeout(() => notification.remove(), 300);
    });
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.transform = 'translateX(400px)';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

function initBackToTop() {
    const backToTopBtn = document.createElement('button');
    backToTopBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
    backToTopBtn.className = 'back-to-top';
    backToTopBtn.style.cssText = `
        position: fixed; bottom: 30px; right: 30px; width: 50px; height: 50px;
        background: linear-gradient(135deg, #DAA520, #8AAF6B); color: #0D1B2A; border: none;
        border-radius: 50%; cursor: pointer; opacity: 0; visibility: hidden;
        transition: all 0.3s ease; z-index: 1000; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
    `;
    
    document.body.appendChild(backToTopBtn);
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 300) {
            backToTopBtn.style.opacity = '1';
            backToTopBtn.style.visibility = 'visible';
        } else {
            backToTopBtn.style.opacity = '0';
            backToTopBtn.style.visibility = 'hidden';
        }
    });
    
    backToTopBtn.addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

function initMobileMenu() {
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');
    
    if (navbarToggler && navbarCollapse) {
        const navLinks = navbarCollapse.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 992) {
                    navbarCollapse.classList.remove('show');
                }
            });
        });
    }
}