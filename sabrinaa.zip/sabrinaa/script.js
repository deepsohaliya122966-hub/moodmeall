// =========================
// GLOBAL API URL
// =========================
// Correctly sets API_BASE_URL for the XAMPP structure (e.g., http://localhost/sabrinaa/api)
const API_BASE_URL = window.location.origin + window.location.pathname.replace(/[^\/]*$/, '').replace(/\/+$/, '') + '/api';

// =========================
// Helper Functions
// =========================

/**
 * Sends a POST request to a MoodMeal API endpoint.
 * @param {string} endpoint - The PHP file name (e.g., 'login.php').
 * @param {object} data - The data to send in the request body.
 * @returns {Promise<object>} The JSON response body from the server.
 */
async function makeApiRequest(endpoint, data) {
    try {
        const response = await fetch(`${API_BASE_URL}/${endpoint}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.message || `Server responded with status ${response.status}`);
        }

        return result;
    } catch (error) {
        return {
            success: false,
            message: error.message || "Unable to connect to server"
        };
    }
}

/**
 * Displays an error message below a specific input field.
 * @param {HTMLInputElement} input - The input element to mark as erroneous.
 * @param {string} message - The error message to display.
 */
function showError(input, message) {
    const formGroup = input.closest('.form-group');
    if (!formGroup) return;

    const errorMsg = formGroup.querySelector(".error-message");
    
    input.classList.add("input-error");
    
    if (errorMsg) {
        errorMsg.textContent = message;
        errorMsg.classList.remove('hidden'); 
        errorMsg.style.display = "block"; 
    }
}

/**
 * Clears all error messages and styles from a form.
 * @param {HTMLFormElement} form - The form element to clear errors from.
 */
function clearErrors(form) {
    form.querySelectorAll("input").forEach(el => el.classList.remove("input-error"));
    form.querySelectorAll(".error-message").forEach(el => {
        el.textContent = "";
        el.classList.add('hidden'); 
        el.style.display = "none";
    });
}

// =========================
// UI Functions (To control forms in index.html)
// =========================
function showLogin() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const successMessage = document.getElementById('successMessage');
    
    // Only run if elements exist (i.e., on index.html)
    if (!loginForm || !registerForm || !successMessage) return;
    
    loginForm.classList.remove('hidden');
    registerForm.classList.add('hidden');
    successMessage.classList.add('hidden');
    
    // Update nav buttons (if they exist)
    const navButtons = document.querySelectorAll('.nav-links .nav-btn');
    if (navButtons[1]) navButtons[1].classList.add('active');
    if (navButtons[2]) navButtons[2].classList.remove('active');
    
    // Clear forms when switching
    const loginFormElement = document.getElementById('loginFormElement');
    if (loginFormElement) {
        loginFormElement.reset();
        clearErrors(loginFormElement);
    }
}

function showRegister() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const successMessage = document.getElementById('successMessage');
    
    // Only run if elements exist (i.e., on index.html)
    if (!loginForm || !registerForm || !successMessage) return;
    
    loginForm.classList.add('hidden');
    registerForm.classList.remove('hidden');
    successMessage.classList.add('hidden');
    
    // Update nav buttons (if they exist)
    const navButtons = document.querySelectorAll('.nav-links .nav-btn');
    if (navButtons[1]) navButtons[1].classList.remove('active');
    if (navButtons[2]) navButtons[2].classList.add('active');
    
    // Clear forms when switching
    const registerFormElement = document.getElementById('registerFormElement');
    if (registerFormElement) {
        registerFormElement.reset();
        clearErrors(registerFormElement);
    }
}

function showSuccess(title, text) {
    const successTitle = document.getElementById('successTitle');
    const successText = document.getElementById('successText');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const successMessage = document.getElementById('successMessage');
    
    // Only run if elements exist (i.e., on index.html)
    if (!successTitle || !successText || !successMessage) return;
    
    successTitle.textContent = title;
    successText.textContent = text;
    if (loginForm) loginForm.classList.add('hidden');
    if (registerForm) registerForm.classList.add('hidden');
    successMessage.classList.remove('hidden');
}

function hideSuccess() {
    const successMessage = document.getElementById('successMessage');
    if (successMessage) {
        successMessage.classList.add('hidden');
        showLogin(); // Always transition back to the login form
    }
}

function openForgotPasswordModal() {
    const modal = document.getElementById('forgotPasswordModal');
    if (modal) modal.classList.remove('hidden');
}

function closeForgotPasswordModal() {
    const modal = document.getElementById('forgotPasswordModal');
    const form = document.getElementById('forgotPasswordForm');
    if (form) {
        form.reset();
        clearErrors(form);
    }
    if (modal) modal.classList.add('hidden');
}


// =========================
// Registration Handler
// =========================
async function handleRegister(event) {
    event.preventDefault();
    const form = event.target;
    clearErrors(form);

    const formData = new FormData(form);
    const data = {
        name: formData.get("name"),
        email: formData.get("email"),
        password: formData.get("password"),
        confirmPassword: formData.get("confirmPassword")
    };

    const result = await makeApiRequest("register.php", data);

    if (result.success) {
        // Redirect to OTP verification page with email
        const email = result.email || data.email;
        window.location.href = `verify-otp.html?email=${encodeURIComponent(email)}`;
    } else {
        // Handle specific field errors (from 400 response code)
        if (result.errors) {
            if (result.errors.name) showError(form.querySelector('#registerName'), result.errors.name);
            if (result.errors.email) showError(form.querySelector('#registerEmail'), result.errors.email);
            if (result.errors.password) {
                showError(form.querySelector('#registerPassword'), result.errors.password);
                showError(form.querySelector('#confirmPassword'), result.errors.password);
            }
        } else {
            // Handle general errors - show detailed error message
            const errorMessage = result.message || result.error || "Registration failed due to server error.";
            showError(form.querySelector('#registerEmail'), errorMessage);
            
            // If there's a note, show it as well
            if (result.note) {
                console.warn("Registration Note:", result.note);
            }
        }
    }
}

// =========================
// Login Handler
// =========================
async function handleLogin(event) {
    event.preventDefault();
    const form = event.target;
    clearErrors(form);

    const formData = new FormData(form);
    const email = formData.get("email");
    const password = formData.get("password");

    const result = await makeApiRequest("login.php", { email, password });

    if (result.success) {
        // Store session data
        sessionStorage.setItem("moodMealSessionToken", result.session_token);
        sessionStorage.setItem("moodMealUser", JSON.stringify(result.user));

        // FIX: Show success box instead of immediate redirect
        showSuccess('Login Successful', 'Your login is successful! Redirecting you to the home page...');

        // Automatically redirect after 3 seconds
        setTimeout(() => {
            // FIX: Redirect to home.html as requested
            window.location.href = "home.html"; 
        }, 3000); 

    } else {
        // Check if user needs email verification
        if (result.needs_verification && result.email) {
            // Redirect to OTP verification page
            showSuccess('Email Verification Required', 'Please verify your email address before logging in. Redirecting to verification page...');
            setTimeout(() => {
                window.location.href = `verify-otp.html?email=${encodeURIComponent(result.email)}`;
            }, 2000);
        } else {
            // Display a generic error message for invalid credentials
            const errorMessage = result.message || "Invalid email or password. Please try again.";
            
            showError(form.querySelector("#loginEmail"), errorMessage);
            showError(form.querySelector("#loginPassword"), errorMessage);
        }
    }
}

// =========================
// Forgot Password Handler
// =========================
async function handleForgotPassword(event) {
    event.preventDefault();
    const form = event.target;
    clearErrors(form);

    const formData = new FormData(form);
    const data = { email: formData.get("email") };

    const result = await makeApiRequest("forgot-password.php", data);

    if (result.success) {
        closeForgotPasswordModal();
        showSuccess('Check your email', 'A password reset link has been sent to your email address.');
    } else if (result.errors && result.errors.email) {
        showError(form.querySelector("#forgotEmail"), result.errors.email);
    } else {
        const fallbackError = result.message || "Unable to send reset link. Please try again.";
        showError(form.querySelector("#forgotEmail"), fallbackError);
    }
}

// =========================
// Session & Logout Functions
// =========================
async function validateSession() {
    const token = sessionStorage.getItem("moodMealSessionToken");
    if (!token) return false;

    const result = await makeApiRequest("validate-session.php", { session_token: token });

    return result.success ? result.user : false;
}

/**
 * Clears local session and invalidates server token.
 */
async function logout() {
    const token = sessionStorage.getItem("moodMealSessionToken");

    if (token) {
        try {
            // Send request to invalidate token on the server
            await makeApiRequest("logout.php", { session_token: token });
        } catch (e) {
            console.error("Server logout failed, clearing local session anyway.", e);
        }
    }
    
    // Clear local data
    sessionStorage.removeItem("moodMealSessionToken");
    sessionStorage.removeItem("moodMealUser");
    
    // Redirect to login page
    window.location.href = "index.html";
}


// =========================
// Attach Events on Load
// =========================
document.addEventListener("DOMContentLoaded", () => {
    // Attach handlers to the forms in index.html
    const registerFormElement = document.getElementById("registerFormElement");
    if (registerFormElement) registerFormElement.addEventListener("submit", handleRegister);

    const loginFormElement = document.getElementById("loginFormElement");
    if (loginFormElement) loginFormElement.addEventListener("submit", handleLogin);

    const forgotForm = document.getElementById("forgotPasswordForm");
    if (forgotForm) forgotForm.addEventListener("submit", handleForgotPassword);

    const forgotLink = document.getElementById("forgotPasswordLink");
    if (forgotLink) {
        forgotLink.addEventListener("click", (e) => {
            e.preventDefault();
            openForgotPasswordModal();
        });
    }
    
    // Expose UI functions globally for inline HTML event handlers (onclick)
    window.showLogin = showLogin;
    window.showRegister = showRegister;
    window.hideSuccess = hideSuccess; 
    window.closeForgotPasswordModal = closeForgotPasswordModal;
    
    // Initial display logic (only on index.html)
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    if (loginForm && registerForm) {
        // We're on index.html, so initialize the form display
        if (window.location.hash === '#register') {
            showRegister();
        } else {
            showLogin();
        }
    }
});